 <!-- resources/views/tasks.blade.php -->

@extends('layouts.app')

@section('content')

  
 <div class = "container main-container fon" style="margin-top: 100px">
	<div class="panel panel-default">
		<div class="panel-heading">
			Добавление
		</div>
	  
		<div class="panel-body">
		<!-- Отображение ошибок проверки ввода -->
		@include('common.errors')


		<!-- Форма новой задачи -->
			<form action="{{ route('review.store') }}" method="POST" class="form-horizontal mt-3">
			  {{ csrf_field() }}
				{{ method_field('PUT') }}
			  <!-- Имя задачи -->
			  	<label for="review" class="col-sm-3 control-label">Содержание</label>
				<div class="row">
					<div class="col-sm-5">
					  <input  type="text" name="text" id="review-text" class="form-control">
					</div>
				</div>
				<label for="review" class="col-sm-3 control-label">Автор</label>
				<div class="row">
					<div class="col-sm-7">
					 <select name="id_user" class="form-control">
					 <option value="{{ Auth::user()->id }}">{{ Auth::user()->name }}</option>
					 @foreach ($users as $user)
					 <option value="{{ $user->id }}"> {{ $user->name }} </option>
					 @endforeach
					 </select>
					</div>
				</div>
				<div class="col-sm-4">
				  <button type="submit" class="btn btn-primary mt-2 mb-2">
					<i class="fa fa-plus"></i> Оставить отзыв 
				  </button>
				</div>
			  </div>
			 
			</form>
		</div>
	</div>	
</div>
   
@endsection