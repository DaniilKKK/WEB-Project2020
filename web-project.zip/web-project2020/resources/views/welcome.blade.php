@extends('layouts.app')
@section('content')
<!DOCTYPE html>
<html>
<head>
  <title></title>


<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
</head>

<style >
video { 
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    object-fit: cover;
    object-position: center;
}
div#fashion {
  min-height: 100vh;
  display: flex;
  align-items: center;
  justify-content: center;
}

.video-h2 { 
  font-family: Century Schoolbook, Century Schoolbook L, Georgia, serif;
  font-size: 8vmin;
  text-align: center;
  margin: 2rem 3rem 0;
  mix-blend-mode: overlay;
  color: #fff;
  font-weight: 100;
}

.section-150px {
	padding: 150px 0;
}

.intro
{

	font-size: 20px;
	line-height: 40px;
	font-style: italic;
	font-weight: 100;
	color: #959595;
	text-align: center;
	width: 100%;
	margin: 0 auto;
}

.intro-in {
	width: 55%;
	margin: 0 auto;
	text-align: center;
}


.no-padding {
   padding: 0 !important;
   margin: 0 !important;
}
.services 
{
	background-color: #202020;
}
.services .ser-in {
	text-align: left;
	position: relative;
	padding: 15%;
	padding-right: 10%;
	padding-left: 25%;
	padding-bottom: 0px;
}
.services .ser-in .border-left {
	border-left: 10px solid #292f33;
}
.services .ser-part-2 {
	padding: 10%;
	padding-bottom: 1%;
}
.services .ser-part-2 li h6 {
	text-transform: uppercase;
	font-weight: bold;
	margin-bottom: 20px;
}



.img-responsive{
	display: block;
    max-width: 100%;
    height: auto;
}

.margin-bottom-40 {
    margin-bottom: 40px !important;
}

.margin-bottom-50 {
    margin-bottom: 50px !important;
}
.margin-bottom-30 {
    margin-bottom: 30px !important;
}

.border-left {
    border-left-color: rgba(255,255,255,0.09);
    margin-left: -130px;
}
.padding-left-20 {
    padding-left: 20px !important;
}

.margin-top-10 {
    margin-top: 10px !important;
}

.tittle-block h2 {
	font-size: 60px;
	font-weight: bold;
	color:  #959595;
}
.tittle-block h3 {
	line-height: 46px;
	font-weight: bold;
	color:  #959595;
}
.tittle-block p {
	font-family: 'Merriweather', serif;
	font-size: 16px;
	font-style: italic;
	color:  #959595;
}

.title-h2 { 
  font-family: Century Schoolbook, Century Schoolbook L, Georgia, serif;
  font-size: 8vmin;
  text-align: center;
  margin: 2rem 3rem 0;
  mix-blend-mode: overlay;
  color: #fff;
  font-weight: 100;
}
	.btn {

	font-size: 16px;
    line-height: 30px;
    font-style: italic;
    color: #959595;
    margin-top: 20px;
    display: inline-block;
    padding: 0px;
    border-radius: 0px;
    border-bottom: 1px solid #959595;
    padding-bottom: 5px;
    font-weight: 100;

}

.btn:hover{
	color: white;
	border-bottom: 1px solid white;

}
div#fashion {
  min-height: 100vh;
  display: flex;
  align-items: center;
  justify-content: center;
}


/*.footer-bs {
    background-color: #3c3d41;
	padding: 60px 40px;
	color: rgba(255,255,255,1.00);
	margin-bottom: 0px;
	border-bottom-right-radius: 6px;
	border-top-left-radius: 0px;
	border-bottom-left-radius: 6px;
}
.footer-bs .footer-brand, .footer-bs .footer-nav, .footer-bs .footer-social, .footer-bs .footer-ns 
{ padding:10px 25px; }
.footer-bs .footer-nav, .footer-bs .footer-social, .footer-bs .footer-ns 
{ border-color: transparent; }
.footer-bs .footer-brand h2 
{ margin:0px 0px 10px; }
.footer-bs .footer-brand p 
{ font-size:12px; color:rgba(255,255,255,0.70); }

.footer-bs .footer-nav ul.pages 
{ list-style:none; padding:0px; }
.footer-bs .footer-nav ul.pages li 
{ padding:5px 0px;}
.footer-bs .footer-nav ul.pages a 
{ color:rgba(255,255,255,1.00); font-weight:bold; text-transform:uppercase; }
.footer-bs .footer-nav ul.pages a:hover
 { color:rgba(255,255,255,0.80); text-decoration:none; }
.footer-bs .footer-nav h4 {
	font-size: 11px;
	text-transform: uppercase;
	letter-spacing: 3px;
	margin-bottom:10px;
}

.footer-bs .footer-nav ul.list 
{ list-style:none; padding:0px; }
.footer-bs .footer-nav ul.list li
 { padding:5px 0px;}
.footer-bs .footer-nav ul.list a 
{ color:rgba(255,255,255,0.80); }
.footer-bs .footer-nav ul.list a:hover 
{ color:rgba(255,255,255,0.60); text-decoration:none; }

.footer-bs .footer-social ul 
{ list-style:none; padding:0px; }
.footer-bs .footer-social h4 {
	font-size: 11px;
	text-transform: uppercase;
	letter-spacing: 3px;
}
.footer-bs .footer-social li 
{ padding:5px 4px;}
.footer-bs .footer-social a 
{ color:rgba(255,255,255,1.00);}
.footer-bs .footer-social a:hover 
{ color:rgba(255,255,255,0.80); text-decoration:none; }

.footer-bs .footer-ns h4 {
	font-size: 11px;
	text-transform: uppercase;
	letter-spacing: 3px;
	margin-bottom:10px;
}
.footer-bs .footer-ns p 
{ font-size:12px; color:rgba(255,255,255,0.70); }

@media (min-width: 768px) 
{
	.footer-bs .footer-nav, .footer-bs .footer-social, .footer-bs .footer-ns { border-left:solid 1px rgba(255,255,255,0.10); }
}*/

</style>
<body>


<video poster="https://s3-us-west-2.amazonaws.com/s.cdpn.io/4273/fashion.jpg" playsinline autoplay muted loop>
<source src="https://s3-us-west-2.amazonaws.com/s.cdpn.io/4273/fashion.webm" type="video/webm">
<source src="http://thenewcode.com/assets/videos/fashion.mp4" type="video/mp4">
</video>
<div id="fashion">
  <h2 class="video-h2">There’s a brand new dance but I don’t know its name…</h2>
</div>


<section style="background-color: #202020; margin-top: -18px;" class="intro section-150px">
        <div class="container">
          <div class="intro-in">
            <p>Если ты не знаешь, что делать с бутсами
            <br> 
              отдай их нам, <strong>а ньансы мы обсудим потом.</strong> </p>
            <a href="#" class="btn">Узнать больше</a>
             </div>
        </div>
</section>


      <section class="services">
        <div class="container-fluid"> 

          <div class="row">
            <div class="col-md-6 "> 
              <div class="ser-in">
                <div class="tittle-block margin-bottom-40">
                  <h2 class="margin-bottom-30" style="margin-left: -180px; margin-top: -115px;">Мы изобретаем бутсы заново</h2>
                  <p style="margin-left: -180px;">И верим в то, что та работа, которую мы делаем является отражением нас самих.</p>
                </div>
                <p class="border-left padding-left-20 margin-top-10" style="margin-left: -180px; color: #CFD0CF" >
Нам потребовалось много усилий и времени, чтобы вернуться туда, откуда все начиналось, мы наблюдали за ногами футболистов, за тем, в чем они играют и поэтому многое переосмыслили,мы переосмыслили полностью футбольную обувь и создали ее заново с использованием новейшихматериалов и технологий.</p>
                <a href="{{ route('Boot') }}" class="btn"style="margin-left: -180px;" >Посмотреть наши работы</a> </div>
            </div>
            

            <div class="col-md-6 no-padding" > <img class="img-responsive" src="http://gigafootball.net/date/photos/1178/715c35df011b4eca1cded2a5cd07b306.jpg"  alt="" > </div>
          </div>
          

          <div class="row"> 
            

            <div class="col-md-6 no-padding"> <img class="img-responsive" src="http://files2020.std-1120.ist.mospolytech.ru/boots.jpg" alt="" > 
            </div>

            <div class="col-md-6">
              <div class="ser-part-2">
                <div class="tittle-block margin-bottom-40">
                  <h3 class="margin-bottom-30 margin-top-0">From Pro VFX to simple Photo <br>
                    Retouching, we’re Kickass!</h3>
                  <p>We are a team of eight sharing our expertise in Professional level <br>
                    Animation to Branding, Packaging and pretty Photography</p>
                </div>
                <ul class="row">

                  <li class="col-sm-6 margin-bottom-50 " >
                    <p style="color: #CFD0CF">We are a team of eight sharing our expertise 
                      in Professional level Animation to Branding, 
                      Packaging and pretty Photography</p>
                  </li>
              </ul>
                
      </section>




<!--<footer class="footer-bs" style="width: 100%">
        <div class="row">
        	<div class="col-md-3 footer-brand animated fadeInLeft">
            	<h2>Logo</h2>
                <p>Suspendisse hendrerit tellus laoreet luctus pharetra. Aliquam porttitor vitae orci nec ultricies. Curabitur vehicula, libero eget faucibus faucibus, purus erat eleifend enim, porta pellentesque ex mi ut sem.</p>
                <p>© 2014 BS3 UI Kit, All rights reserved</p>
            </div>
        	<div class="col-md-4 footer-nav animated fadeInUp">
            	<h4>Menu —</h4>
            	<div class="col-md-6">
                    <ul class="pages">
                        <li><a href="#">Travel</a></li>
                        <li><a href="#">Nature</a></li>
                        <li><a href="#">Explores</a></li>
                        <li><a href="#">Science</a></li>
                        <li><a href="#">Advice</a></li>
                    </ul>
                </div>
            	<div class="col-md-6">
                    <ul class="list">
                        <li><a href="#">About Us</a></li>
                        <li><a href="#">Contacts</a></li>
                        <li><a href="#">Terms & Condition</a></li>
                        <li><a href="#">Privacy Policy</a></li>
                    </ul>
                </div>
            </div>
        	<div class="col-md-2 footer-social animated fadeInDown">
            	<h4>Follow Us</h4>
            	<ul>
                	<li><a href="#">Facebook</a></li>
                	<li><a href="#">Twitter</a></li>
                	<li><a href="#">Instagram</a></li>
                	<li><a href="#">RSS</a></li>
                </ul>
            </div>
        	<div class="col-md-3 footer-ns animated fadeInRight">
            	<h4>Newsletter</h4>
                <p>A rover wearing a fuzzy suit doesn’t alarm the real penguins</p>
                <p>
                    <div class="input-group">
                      <input type="text" class="form-control" placeholder="Search for...">
                      <span class="input-group-btn">
                        
                      </span>
                    </div>
                 </p>
            </div>
        </div>
    </footer>-->



<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>

</body>
</html>



@endsection