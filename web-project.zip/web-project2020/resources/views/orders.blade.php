@extends('layouts.app')
@section('content')
<body>
<div class = "container main-container fon"  style="margin-top: 100px">
     <div class="panel-body">
					<h2 style="background-color:black;  border-radius:3px"><pre style="color:white; margin-top:100px">Заказы</pre></h2>
			<div class="row">
			<h1> Какой-то текст </h1>
			</div>
		<a href="{{ route('order.create') }}" class="form-control btn btn-info">Добавить заказ</a>
        <table class="table table-hover table-dark">
          <thead>
			<th>ID </th>
			<th>Обувь</th>
            <th>Мастер</th>
			<th>Стоимость</th>
			<th>Список работ</th>
			<th>Дата исполнения</th>
			<th> Действие </th>
          </thead>

          <tbody>
            @foreach ($orders as $order)
              <tr>
				<td>
					<div>{{ $order->id }}</div>
				</td>
                <td class="table-text">
					<div>{{ $order->Boots->name }}</div>
                </td>
				<td> 
					<div>{{ $order->Personals->name }}</div>
				</td>
				<td> 
					<div>{{ $order->cost }}</div>
				</td>
				<td> 
					<div>{{ $order->work }}</div>
				</td>
				<td> 
					<div>{{ $order->dateR }}</div>
				</td>
				@if ( Auth::user()->id_personal == $order->id_personal )
				<td> 
						<a href="{{ route('order.edit', $order) }}" class="form-control mt-2">Редактировать</a>
						<form action="{{ route('order.destroy', [$order->id]) }}" method="POST">
						{{ csrf_field() }}
						{{ method_field('DELETE') }}
						<div class="col-sm-4">
						  <button type="submit" class="btn btn-danger mt-2">
							<i class="fa fa-plus"></i> Удалить 
						  </button>
						</div>
						</form>
				</td>
				@endif
              </tr>
            @endforeach
          </tbody>
        </table>
		<div class = "col-md-6 col-12"> 
			{{ $orders->links('layouts.paginate') }} 
</div>
	</div>
 </div>	
</body>
@endsection