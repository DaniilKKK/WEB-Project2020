@extends('layouts.app')
@section('content')
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<div class="container">
     <div class="panel-body">
		<div class="row">
			<h1> Какой-то текст </h1>
		</div>
		<hr>
		<h2 style="background-color:Black;  border-radius:3px"><pre style="color:white;">  Наши мастера</pre></h2>
		@if ((!empty(Auth::user())) &&  ( Auth::user()->type== 'admin' ))
			<a href="{{ route('personal.create') }}" class="form-control btn btn-info">Добавить сотрудника</a>
		@endif
        <table class="table table-hover table-dark">
          <thead>
		  
			<th></th>
            <th>ФИО</th>
			<th>Специализация</th>
			<th>Телефон</th>
			@if ((!empty(Auth::user())) &&  ( Auth::user()->type == 'admin' ))
			<th>Действия</th>
			@endif
          </thead>

          <tbody>
		  				
            @foreach ($personals as $personal)
              <tr>
				<td> 
					<div><img src="{{ $personal->picture }}" alt="pict" width="50%"></div>
				</td>
                <td class="table-text">
					<div>{{ $personal->name }}</div>
                </td>
				
				<td> 
					<div>{{ $personal->work}}</div>
				</td>
				<td> 
					<div>{{ $personal->phone }}</div>
				</td>
				@if ((!empty(Auth::user())) &&  ( Auth::user()->type == 'admin' ))
				 <td>
						<a href="{{ route('personal.edit', $personal) }}" class="form-control">Редактировать</a>
						<form action="{{route('personal.destroy', [$personal->id])}}" method="POST">
						{{ csrf_field() }}
						{{ method_field('DELETE') }}
						<div class="col-sm-4">
						  <button type="submit" class="btn btn-danger mt-2">
							<i class="fa fa-plus"></i> Удалить 
						  </button>
						</div>
						</form>
				</td>
				@endif
              </tr>
            @endforeach
          </tbody>
        </table>
		<div class = "col-md-6 col-12"> 
				{{ $personals->links('layouts.paginate') }} 
		</div>

		</div>
	</div>
</body>		
</html>
@endsection