@extends('layouts.app')
@section('content')
<div class = "container main-container fon" style="margin-top: 100px">
     <div class="panel-body">
		<div class="row">
			<h1> Какой-то текст </h1>
		</div>
		<hr>
		<h2 style="background-color:Black;  border-radius:3px"><pre style="color:white;"> Обувь</pre></h2>
		@if ((!empty(Auth::user())) &&  ( Auth::user()->type == 'admin' ))
		<a href="{{ route('boot.create') }}" class="form-control btn btn-info">Добавить обувь</a>
		@endif
        <table class="table table-hover table-dark">
          <thead>
		  
			<th></th>
            <th>Название модели</th>
			<th>Описание</th>
			@if ((!empty(Auth::user())) &&  ( Auth::user()->type == 'admin' ))
			<th>Действия</th>
			@endif
          </thead>

          <tbody>
		  				
            @foreach ($boots as $boot)
              <tr>
				<td> 
					<div><img src="{{ $boot->picture }}" alt="pict" width="50%"></div>
				</td>
                <td class="table-text">
					<div>{{ $boot->name }}</div>
                </td>
				<td> 
					<div>{{ $boot->description}}</div>
				</td>
				@if ((!empty(Auth::user())) &&  ( Auth::user()->type == 'admin' ))
				 <td>
						<a href="{{ route('boot.edit', $boot) }}" class="form-control">Редактировать</a>
						<form action="{{route('boot.destroy', [$boot->id])}}" method="POST">
						{{ csrf_field() }}
						{{ method_field('DELETE') }}
						<div class="col-sm-4">
						  <button type="submit" class="btn btn-danger mt-2">
							<i class="fa fa-plus"></i> Удалить 
						  </button>
						</div>
						</form>
				</td>
				@endif
              </tr>
            @endforeach
          </tbody>
        </table>
		<div class = "col-md-6 col-12"> 
				{{ $boots->links('layouts.paginate') }} 
		</div>

		</div>
		</div>

@endsection