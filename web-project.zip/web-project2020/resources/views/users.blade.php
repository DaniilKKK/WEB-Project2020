@extends('layouts.app')
@section('content')
<body>
<div class = "container main-container fon"  style="margin-top: 100px">
     <div class="panel-body">
		<h2 style="background-color:SandyBrown;  border-radius:3px"><pre style="color:white; margin-top:100px">Пользователи</pre></h2>
		<a href="{{ route('user.create') }}" class="form-control btn btn-info">Добавить пользователя</a>
        <table class="table table-striped task-table table-bordered">
          <thead>
			<th>Имя </th>
			<th>email</th>
            <th>Уровень привилегий</th>
			<th> Действие </th>
          </thead>

          <tbody>
            @foreach ($users as $user)
              <tr>
				<td>
					<div>{{ $user->name }}</div>
				</td>
                <td class="table-text">
					<div>{{ $user->email }}</div>
                </td>
				<td> 
					<div>{{ $user->type }}</div>
				</td>
			
				<td> 
						<a href="{{ route('user.edit', $user) }}" class="form-control mt-2">Редактировать</a>
						<form action="{{route('user.destroy', [$user->id])}}" method="POST">
						{{ csrf_field() }}
						{{ method_field('DELETE') }}
						<div class="col-sm-4">
						  <button type="submit" class="btn btn-danger mt-2">
							<i class="fa fa-plus"></i> Удалить 
						  </button>
						</div>
						</form>
				</td>
              </tr>
            @endforeach
          </tbody>
        </table>
		<div class = "col-md-6 col-12"> 
			{{ $users->links('layouts.paginate') }} 
		</div>
	</div>
 </div>	
</body>
@endsection