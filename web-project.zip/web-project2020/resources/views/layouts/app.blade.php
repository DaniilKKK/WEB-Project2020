<!DOCTYPE html>
<html lang="en">
  <head>
	<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>ZIGGY</title>
	<!--<link rel="shortcut icon" href="" type="image/png">-->
   	<link rel="stylesheet" href="//netdna.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">        
	<style>
@font-face {
  font-family: Moderne Sans;
  src: url(https://s3-us-west-2.amazonaws.com/s.cdpn.io/4273/moderne_sans.woff2)
}
* {
  box-sizing: border-box;
}
body {
  margin: 0;
}

header 
{
  position: absolute;
  width: 100%;
  text-align: center;
  color: white;
  transition: .4s;
}
header:hover {
  background: rgba(255,255,255,0.8);
  color: #000;
}
h1 {
  font-family: Moderne Sans, sans-serif;
  text-align: center;
  font-size: 2rem;
  width: 100%;
  letter-spacing: .5rem;
}
nav a {
  text-decoration: none;
  color: inherit;
  padding: 1rem;
}
nav a:hover {
  text-decoration:  underline;
  color: inherit;
  padding: 1rem;
}


		
  </style>
	 <script>
        window.Laravel = <?php echo json_encode([
            'csrfToken' => csrf_token(),
        ]); ?>



    </script>
  </head>




  

<body>

<div class="fixed-top">
<header>
<h1>ZIGGY</h1>

  <nav >
    <a  href="{{ route('Welcome') }}">Главная <span class="sr-only">(current)</span></a>
    <a  href="{{ route('Personal') }}">Персонал</a>
    <a  href="{{ route('Boot') }}">Обувная лента</a>
    <a  href="{{ route('Review') }}">Форум</a>

        @if ((!empty(Auth::user())) &&  (( Auth::user()->type == 'admin' ) || ( Auth::user()->type == 'personal' )))
        
        <a href="{{ route('Order') }}">Заказы</a>
      
        @endif
        @if ((!empty(Auth::user())) &&  ( Auth::user()->type == 'admin' ))
        
        <a  href="{{ route('User') }}">Пользователи</a>
    
        @endif

         
                        
                       @if (Auth::guest())
                            <a href="{{ url('/login') }}" class="">Login</a>
                            <a href="{{ url('/register') }}" class="ml-2">Register</a>
                        @else
                            <span class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">
                                    {{ Auth::user()->name }} <span class="caret"></span>
                                </a>

                               
                                  
                                        <a href="{{ url('/logout') }}"
                                            onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();" class="">
                                            Выйти
                                        </a>

                                        <form id="logout-form" action="{{ url('/logout') }}" method="POST" style="display: none;">
                                            {{ csrf_field() }}
                                        </form>
                                    </span>
                        
                           
                        @endif
                   
    </nav>

</header>
</div>



    @yield('content')

	<script src="/js/app.js"></script>
	<script src="https://code.jquery.com/jquery.js"></script>
	<script src="http://netdna.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
  </body>
</html>