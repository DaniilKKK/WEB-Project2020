@extends('layouts.app')

@section('content')


<!DOCTYPE html>
<html>
<head>
<style >
body 
{
    margin:  0;
}
.page-content {
    width: 100%;
    margin:  0 auto;
    background-color: #959595;
    display: flex;
    display: -webkit-flex;
    justify-content: center;
}
.form-v2-content  {
    background: #f7f7f7;
    width: 851px;
    border-radius: 15px;
    margin: 100px 0;
    position: relative;
    display: flex;
}
.form-v2-content .form-left {
    margin-bottom: -4px;
    position: relative;
}
.form-v2-content .form-left img {
    border-top-left-radius: 15px;
    border-bottom-left-radius: 15px;
}
.form-v2-content .form-left .text-1,
.form-v2-content .form-left .text-2 {
    font-family: 'Roboto', sans-serif;
    font-weight: 700;
    color: #fff;
}
.form-v2-content .form-left .text-1 {
    position: absolute;
    left: 9%;
    bottom: 15%;
}
.form-v2-content .form-left .text-2 {
    position: absolute;
    right: 8%;
    bottom: 1.5%;
}
.form-v2-content .form-left .text-1 p {
    font-size: 32px;
    line-height: 1.67;
}
.form-v2-content .form-left .text-1 span {
    font-size: 25px;
    display: block;
}
.form-v2-content .form-left .text-2 p {
    font-size: 18px;
}
.form-v2-content .form-left .text-2 span {
    font-size: 35px;
    padding-right: 9px;
}
.form-v2-content .form-detail {
    padding: 20px 40px 20px 40px;
    position: relative;
    width: 100%;
}
.form-v2-content .form-detail h2 {
    font-family: 'Roboto', sans-serif;
    font-weight: 700;
    color: #333;
    font-size: 28px;
    position: relative;
    padding: 6px 0 0;
    margin-bottom: 25px;
    margin-top: 40px;
}
.form-v2-content .form-row {
    width: 100%;
    position: relative;
}
.form-v2-content .form-detail label {
    font-family: 'Roboto', sans-serif;
    font-weight: 400;
    font-size: 16px;
    color: #666;
    display: block;
    margin-bottom: 11px;
}

.form-v2-content .form-detail .input-text {
    margin-bottom: 27px;
}
.form-v2-content .form-detail input {
    width: 91%;
    padding: 14.5px 15px;
    border: 1px solid #e5e5e5;
    border-radius: 5px;
    font-family: 'Roboto', sans-serif;
    font-size: 16px;
    color: #333;
}
.form-v2-content .form-detail .form-checkbox {
    width: 80%;
    margin-top: -17px;
    position: relative;
}
.form-v2-content .form-detail .form-checkbox input {
    position: absolute;
    opacity: 0;
}
.form-v2-content .form-detail .form-checkbox .checkmark {
    position: absolute;
    top: 20px;
    left: 0;
    height: 15px;
    width: 15px;
    border: 1px solid #ccc;
    cursor: pointer;
}
.form-v2-content .form-detail .form-checkbox .checkmark::after {
    content: "";
    position: absolute;
    left: 5px;
    top: 1px;
    width: 3px;
    height: 8px;
    border: 1px solid #385cb9;
    border-width: 0 2px 2px 0;
    display: none;
}
.form-v2-content .form-detail .form-checkbox p {
    margin-left: 35px;
    color: #666;
    font-size: 16px;
    font-weight: 400;
    font-family: 'Roboto', sans-serif;
    line-height: 1.67;
}
.form-v2-content .form-detail .form-checkbox a {
    font-weight: 500;
    color: #385cb9;
    text-decoration: underline;
}
.form-v2-content .form-detail .register {
    background: #3b63ca;
    border-radius: 6px;
    width: 160px;
    border: none;
    margin: 6px 0 50px 0px;
    cursor: pointer;
    font-family: 'Roboto', sans-serif;
    color: #fff;
    font-weight: 500;
    font-size: 16px;
}
.form-v2-content .form-detail .register:hover {
    background: #3356b0;
}
.form-v2-content .form-detail .form-row-last input {
    padding: 15.5px;
}


</style>
</head>

<body class="form-v2">
    <div class="page-content">
        <div class="form-v2-content">
            <div class="form-left">
                <img src="https://i.pinimg.com/736x/8a/05/33/8a053319bd263f33acaccd922f55e451.jpg" style="width: 447px; height: 724px;" alt="form">
            </div>
            <form class="form-detail" role="form" ction="{{ url('/register') }}" method="post" >
                {{ csrf_field() }}
                <h2>Registration Form</h2>
                <div class="form-row{{ $errors->has('name') ? ' has-error' : '' }}">
                    <label for="full-name">Full Name:</label>
                    <input id="name" type="text" class="input-text" name="name" value="{{ old('name') }}" required autofocus>
                     @if ($errors->has('name'))
                            <span class="help-block">
                                <strong>{{ $errors->first('name') }}</strong>
                            </span>
                    @endif
                </div>


                <div class="form-row{{ $errors->has('email') ? ' has-error' : '' }}">
                    <label for="email">Your Email:</label>
                    <input id="email" type="email" class="input-text" name="email" value="{{ old('email') }}" required>
                    @if ($errors->has('email'))
                        <span class="help-block">
                            <strong>{{ $errors->first('email') }}</strong>
                        </span>
                    @endif
                </div>


                <div class="form-row{{ $errors->has('password') ? ' has-error' : '' }}">
                    <label for="password">Password:</label>
                    <input id="password" type="password"  class="input-text" name="password" required>
                    @if ($errors->has('password'))
                        <span class="help-block">
                            <strong>{{ $errors->first('password') }}</strong>
                        </span>
                    @endif
                </div>


                <div class="form-row">
                    <label for="password-confirm">Confirm Password:</label>
                    <input id="password-confirm" type="password" class="input-text" name="password_confirmation" required>
                </div>
                
                <div class="form-row-last">
                    <input type="submit" name="register" class="register" value="Register">
                </div>
            </form>
        </div>
    </div>
</body>
</html>
@endsection
