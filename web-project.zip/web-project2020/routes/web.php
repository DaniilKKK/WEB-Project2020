<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| This file is where you may define all of the routes that are handled
| by your application. Just tell Laravel the URIs it should respond
| to using a Closure or controller method. Build something great!
|
*/

Route::get('/', 'MainController@index')->name('Welcome');
Route::get('/personals', 'MainController@indexPersonal')->name('Personal');
Route::get('/boots', 'MainController@indexBoot')->name('Boot');
Route::get('/orders', 'MainController@indexOrder')->name('Order');
Route::get('/reviews', 'MainController@indexReview')->name('Review');

/* Свой middleware */
Route::resource('review', 'ReviewController');
Route::resource('order', 'OrderController');

Route::group(['middleware' => 'type'], function()
{
Route::resource('personal', 'PersonalController');
Route::resource('boot', 'BootsController');
Route::resource('user', 'UserController');
Route::get('/users', 'MainController@indexUser')->name('User');
});
Auth::routes();
