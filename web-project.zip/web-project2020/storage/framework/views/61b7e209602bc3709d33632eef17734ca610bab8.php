 <!-- resources/views/tasks.blade.php -->



<?php $__env->startSection('content'); ?>

  
 <div class = "container main-container fon" style="margin-top: 100px">
	<div class="panel panel-default">
		<div class="panel-heading">
			Редактирование
		</div>
	  
		<div class="panel-body">
		<!-- Отображение ошибок проверки ввода -->
		<?php echo $__env->make('common.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


		<!-- Форма новой задачи -->
			<form action="<?php echo e(route('user.store')); ?>" method="POST" class="form-horizontal mt-3">
			  <?php echo e(csrf_field()); ?>

			  <!-- Имя задачи -->
			  <div class="form-group">
				<label for="user" class="col-sm-3 control-label">Имя</label>
				<div class="row">
					<div class="col-sm-5">
					  <input  type="text" name="name" id="user-name" class="form-control">
					</div>
				</div>
				<label for="user" class="col-sm-3 control-label">email</label>
				<div class="row">
					<div class="col-sm-5">
					  <input  type="text" name="email" id="user-email" class="form-control">
					</div>
				</div>
				<label for="user" class="col-sm-3 control-label">Пароль</label>
				<div class="row">
					<div class="col-sm-5">
					  <input  type="password" name="password" id="user-password" class="form-control">
					</div>
				</div>
				<label for="user" class="col-sm-3 control-label">Уровень привилегий</label>
				<div class="row">
					<div class="col-sm-7">
					 <select name="type" class="form-control">
					 <option value="user"> Пользователь </option>
					 <option value="admin"> Админ </option>
					 </select>
					</div>
				</div>
				<label for="order" class="col-sm-3 control-label">Сотрудник </label>
				<div class="row">
					<div class="col-sm-7">
					 <select name="id_personal" class="form-control">
					 <option>Не является аккаунтом сотрудника</option>
					 <?php $__currentLoopData = $personals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $personal): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
					 <option value="<?php echo e($personal->id); ?>"> <?php echo e($personal->name); ?> </option>
					 <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
					 </select>
					</div>
				</div>
				
				<div class="col-sm-4">
				  <button type="submit" class="btn btn-primary mt-2 mb-2">
					<i class="fa fa-plus"></i> Создать 
				  </button>
				</div>
			  </div>
			 
			</form>
		</div>
	</div>	
</div>
   
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>