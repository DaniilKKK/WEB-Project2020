
<?php $__env->startSection('content'); ?>
<body>
<div class = "container main-container fon"  style="margin-top: 100px">
     <div class="panel-body">
					<h2 style="background-color:black;  border-radius:3px"><pre style="color:white; margin-top:100px">Заказы</pre></h2>
			<div class="row">
			<h1> Какой-то текст </h1>
			</div>
		<a href="<?php echo e(route('order.create')); ?>" class="form-control btn btn-info">Добавить заказ</a>
        <table class="table table-hover table-dark">
          <thead>
			<th>ID </th>
			<th>Обувь</th>
            <th>Мастер</th>
			<th>Стоимость</th>
			<th>Список работ</th>
			<th>Дата исполнения</th>
			<th> Действие </th>
          </thead>

          <tbody>
            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
              <tr>
				<td>
					<div><?php echo e($order->id); ?></div>
				</td>
                <td class="table-text">
					<div><?php echo e($order->Boots->name); ?></div>
                </td>
				<td> 
					<div><?php echo e($order->Personals->name); ?></div>
				</td>
				<td> 
					<div><?php echo e($order->cost); ?></div>
				</td>
				<td> 
					<div><?php echo e($order->work); ?></div>
				</td>
				<td> 
					<div><?php echo e($order->dateR); ?></div>
				</td>
				<?php if( Auth::user()->id_personal == $order->id_personal ): ?>
				<td> 
						<a href="<?php echo e(route('order.edit', $order)); ?>" class="form-control mt-2">Редактировать</a>
						<form action="<?php echo e(route('order.destroy', [$order->id])); ?>" method="POST">
						<?php echo e(csrf_field()); ?>

						<?php echo e(method_field('DELETE')); ?>

						<div class="col-sm-4">
						  <button type="submit" class="btn btn-danger mt-2">
							<i class="fa fa-plus"></i> Удалить 
						  </button>
						</div>
						</form>
				</td>
				<?php endif; ?>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
          </tbody>
        </table>
		<div class = "col-md-6 col-12"> 
			<?php echo e($orders->links('layouts.paginate')); ?> 
</div>
	</div>
 </div>	
</body>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>