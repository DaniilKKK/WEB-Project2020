<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Boot extends Model
{
      public function Order()
	{
		return $this->hasMany('App\Order', 'id_boot');
	}
	
	public function User()
	{
		return $this->belongsTo('App\User', 'id_user');
	}
}
