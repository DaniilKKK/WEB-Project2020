
 
<?php if($paginator->lastPage() > 1): ?> 
<ul class="pagination"> 
<li class="<?php echo e(($paginator->currentPage() == 1) ? ' disabled' : ''); ?> page-item"> 
<a href="<?php echo e($paginator->url($paginator->currentPage()-1)); ?>" class = "page-link">Предыдущая</a> 
</li> 
<?php for($i = 1; $i <= $paginator->lastPage(); $i++): ?> 
<li class="<?php echo e(($paginator->currentPage() == $i) ? ' active' : ''); ?> page-item"> 
<a href="<?php echo e($paginator->url($i)); ?>" class = "page-link"><?php echo e($i); ?></a> 
</li> 
<?php endfor; ?> 
<li class="<?php echo e(($paginator->currentPage() == $paginator->lastPage()) ? ' disabled' : ''); ?> page-item"> 
<a href="<?php echo e($paginator->url($paginator->currentPage()+1)); ?> " class = "page-link">Следующая</a> 
</li> 
</ul> 
<?php endif; ?>