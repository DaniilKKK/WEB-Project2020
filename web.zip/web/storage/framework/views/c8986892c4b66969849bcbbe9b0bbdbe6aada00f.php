<?php $__env->startSection('content'); ?>

<!DOCTYPE html>
<html>
<head>
    <title></title>

<style>

.limiter {
  width: 100%;
  margin: 0 auto;
}

.container-login100 {
  width: 100%;  
  min-height: 100vh;
  justify-content: center;
  align-items: center;
  background: #f2f2f2;
}


.wrap-login100 {
  width: 100%;
  background: #fff;
  display: flex;
  align-items: stretch;
  flex-direction: row-reverse;

}

.login100-more {
  width: calc(100% - 560px);
  background-repeat: no-repeat;
  background-size: cover;
  background-position: center;
  position: relative;
  z-index: 1;
}

.login100-more::before {
  content: "";
  display: block;
  position: absolute;
  z-index: -1;
  width: 100%;
  height: 100%;
  top: 0;
  left: 0;
  background: rgba(0,0,0,0.1);
}

.login100-form {
  width: 560px;
  min-height: 100vh;
  display: block;
  background-color: #c0c0c0;
  padding: 173px 55px 55px 55px;
}

.login100-form-title {
  width: 100%;
  display: block;
  font-family: Poppins-Regular;
  font-size: 30px;
  color: #333333;
  line-height: 1.2;
  text-align: center;
  margin-bottom: 40px;
  margin-top: -43px;
}


.label-input100 {
  font-family: Montserrat-Regular;
  font-size: 18px;
  color: #999999;
  line-height: 1.2;

  display: block;
  position: absolute;
}


.input100 {
  display: block;
  width: 100%;
  background: transparent;
  font-family: Montserrat-Regular;
  font-size: 21px;
  color: #555555;
  line-height: 1.2;
  padding: 0 26px;
  margin-bottom: 10px;
  margin-top: 10px;
  margin-left: -10px;
}
.inputSIZE
{
	text-align: center;

}

.login100-form-btn {
  justify-content: center;
  align-items: center;
  padding: 0 20px;
  width: 100%;
  height: 50px;
  border-radius: 10px;
  background: #6675df;

  font-family: Montserrat-Bold;
  font-size: 12px;
  color: #fff;
  line-height: 1.2;
  text-transform: uppercase;
  letter-spacing: 1px;
}

.login100-form-btn:hover {
  background: #333333;
}

.flex-sb-m {
    display: -webkit-box;
    display: -webkit-flex;
    display: -moz-box;
    display: -ms-flexbox;
    display: flex;
    justify-content: space-between;
    -ms-align-items: center;
    align-items: center;
}

.w-full {
    width: 100%;
}
.p-b-32 {
    padding-bottom: 22px;
}

.p-t-3 {
    padding-top: 30px;
}

.p-t-46 {
    padding-top: 46px;
}

.p-t-20 {
    padding-top: 20px;
}

a:hover {
    text-decoration: none;
    color: #6675df;
}

.txt1 {
    font-family: Montserrat-Regular;
    font-size: 18px;
    line-height: 1.4;
    color: #555;
}
a {

    line-height: 1.7;
    color: #666;
    margin: 0;
    transition: all .4s;
    -webkit-transition: all .4s;
    -o-transition: all .4s;
    -moz-transition: all .4s;
}

.label-checkbox100 {
    font-family: Poppins-Regular;
    font-size: 18px;
    color: #555;
    line-height: 1.4;
    display: block;
    position: relative;
    padding-left: 26px;
    cursor: pointer;
    margin-top: -5px;
}

.login100-form-social-item {
    width: 36px;
    height: 36px;
    font-size: 18px;
    color: #fff;
    border-radius: 50%;
}

</style>
</head>


<body style="background-color: #666666;">
    
    <div class="limiter">
        <div class="container-login100">
            <div class="wrap-login100">
                <form class="login100-form validate-form" role="form" method="POST" action="<?php echo e(url('/login')); ?>">
                    <?php echo e(csrf_field()); ?>

                    <span class="login100-form-title">
                        Войдите, чтобы продолжить
                    </span>
                    
                    
                        
                        <div class="wrap-input100 validate-input<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                            <label for="email" class="input100" style="text-align: left;">E-Mail Адрес</label>

                            <div >
                              
                                <input id="email" type="email" class="form-control" name="email" value="<?php echo e(old('email')); ?>" required autofocus>

                                <?php if($errors->has('email')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                    
                    
                        <div class="wrap-input100 validate-input<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                            <label for="password" class="input100">Пароль</label>

                            <div >
                                <input id="password" type="password" class="form-control" name="password" required>

                                <?php if($errors->has('password')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>


                    <div class="flex-sb-m w-full p-t-3 p-b-32">
                        <div class="contact100-form-checkbox">
                            <label class="label-checkbox100">
                                <input type="checkbox" style="margin-right: 4px; margin-left: -20px; " name="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>> Запомнить меня
                            </label>
                        </div>

                        <div>
							<a href="<?php echo e(url('/password/reset')); ?>" class="txt1">
								Забыли пароль?
							</a>
						</div>
          				</div>


                        <div>

                        <div class="form-group">
                            <div class="container-login100-form-btn">
                                <button type="submit" class="login100-form-btn" style="margin-top: 10px">
                                    Войти
                                </button>
                            </div>
                        </div>
                        </div>


                  

                </form>

                <div class="login100-more" style="background-image: url('https://images.wallpaperscraft.ru/image/nogi_krossovki_tennisnyj_miach_174640_1920x1080.jpg');">
                </div>
            </div>
        </div>
    </div>
</html>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>