
<?php $__env->startSection('content'); ?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
<style >
body{
background:
        -webkit-linear-gradient(45deg, hsla(0, 0%, 2%, 1) 0%, hsla(0, 0%, 2%, 0) 70%),
        -webkit-linear-gradient(315deg, hsla(0, 0%, 12%, 1) 10%, hsla(0, 0%, 12%, 0) 80%),
        -webkit-linear-gradient(225deg, hsla(0, 0%, 24%, 1) 10%, hsla(0, 0%, 24%, 0) 80%),
        -webkit-linear-gradient(135deg, hsla(0, 0%, 35%, 1) 100%, hsla(0, 0%, 35%, 0) 70%);
    background:
        linear-gradient(45deg, hsla(0, 0%, 2%, 1) 0%, hsla(0, 0%, 2%, 0) 70%),
        linear-gradient(135deg, hsla(0, 0%, 12%, 1) 10%, hsla(0, 0%, 12%, 0) 80%),
        linear-gradient(225deg, hsla(0, 0%, 24%, 1) 10%, hsla(0, 0%, 24%, 0) 80%),
        linear-gradient(315deg, hsla(0, 0%, 35%, 1) 100%, hsla(0, 0%, 35%, 0) 70%);;
	
}
</style>
</head>


<body>
<div class = "container main-container fon"  style="margin-top: 100px">
     <div class="panel-body">
		<a href="<?php echo e(route('user.create')); ?>" class="form-control btn btn-info">Добавить пользователя</a>
        <table class="table  task-table " style="color: white">
          <thead>
			<th>Имя </th>
			<th>email</th>
            <th>Уровень привилегий</th>
			<th> Действие </th>
          </thead>

          <tbody>
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
              <tr>
				<td>
					<div><?php echo e($user->name); ?></div>
				</td>
                <td class="table-text">
					<div><?php echo e($user->email); ?></div>
                </td>
				<td> 
					<div><?php echo e($user->type); ?></div>
				</td>
			
				<td> 
						<a href="<?php echo e(route('user.edit', $user)); ?>" class="form-control mt-2">Редактировать</a>
						<form action="<?php echo e(route('user.destroy', [$user->id])); ?>" method="POST">
						<?php echo e(csrf_field()); ?>

						<?php echo e(method_field('DELETE')); ?>

						<div class="col-sm-4">
						  <button type="submit" class="btn btn-danger mt-2">
							<i class="fa fa-plus"></i> Удалить 
						  </button>
						</div>
						</form>
				</td>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
          </tbody>
        </table>
		<div class = "col-md-6 col-12"> 
			<?php echo e($users->links('layouts.paginate')); ?> 
		</div>
	</div>
 </div>	
</body>
</html>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>