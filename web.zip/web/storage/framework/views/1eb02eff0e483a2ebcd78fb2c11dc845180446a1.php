
<?php $__env->startSection('content'); ?>
<!DOCTYPE html>
<html>
<head>


	<style >
	@import  url(https://fonts.googleapis.com/css?family=Source+Sans+Pro:400,200,200italic,300,300italic,400italic,600,600italic,700,700italic,900,900italic);

body {
    font-family: 'Source Sans Pro', sans-serif;
    line-height: 1.5;
    background:
        -webkit-linear-gradient(45deg, hsla(0, 0%, 2%, 1) 0%, hsla(0, 0%, 2%, 0) 70%),
        -webkit-linear-gradient(315deg, hsla(0, 0%, 12%, 1) 10%, hsla(0, 0%, 12%, 0) 80%),
        -webkit-linear-gradient(225deg, hsla(0, 0%, 24%, 1) 10%, hsla(0, 0%, 24%, 0) 80%),
        -webkit-linear-gradient(135deg, hsla(0, 0%, 35%, 1) 100%, hsla(0, 0%, 35%, 0) 70%);
    background:
        linear-gradient(45deg, hsla(0, 0%, 2%, 1) 0%, hsla(0, 0%, 2%, 0) 70%),
        linear-gradient(135deg, hsla(0, 0%, 12%, 1) 10%, hsla(0, 0%, 12%, 0) 80%),
        linear-gradient(225deg, hsla(0, 0%, 24%, 1) 10%, hsla(0, 0%, 24%, 0) 80%),
        linear-gradient(315deg, hsla(0, 0%, 35%, 1) 100%, hsla(0, 0%, 35%, 0) 70%);;
    /*color: #323232;*/
    font-size: 15px;
    font-weight: 400;
    text-rendering: optimizeLegibility;

    -webkit-font-smoothing: antialiased;
    -moz-font-smoothing: antialiased;
}
.heading-title {
    margin-bottom: 100px;
}
.text-center {
    text-align: center;
}
.heading-title h3 {
    margin-bottom: 0;
    letter-spacing: 2px;
    font-weight: normal;
}
.p-top-30 {
    padding-top: 30px;
}
.half-txt {
    width: 60%;
    margin: 0 auto;
    display: inline-block;
    line-height: 25px;
    color: #7e7e7e;
}
.text-uppercase {
    text-transform: uppercase;
}

.team-member, .team-member .team-img {
    position: relative;
}
.team-member {
    overflow: hidden;
}
.team-member, .team-member .team-img {
    position: relative;


}

.team-hover {
    position: absolute;
    top: 0;
    left: 0;
    bottom: 0;
    right: 0;
    margin: 0;
    border: 20px solid rgba(0, 0, 0, 0.1);
    background-color: rgba(255, 255, 255, 0.90);
    opacity: 0;
    -webkit-transition: all 0.3s;
    transition: all 0.3s;
}
.team-member:hover .team-hover .desk {
    top: 35%;
}
.team-member:hover .team-hover, .team-member:hover .team-hover .desk, .team-member:hover .team-hover .s-link {
    opacity: 1;
}
.team-hover .desk {
    position: absolute;
    top: 0%;
    width: 100%;
    opacity: 0;
    -webkit-transform: translateY(-55%);
    -ms-transform: translateY(-55%);
    transform: translateY(-55%);
    -webkit-transition: all 0.3s 0.2s;
    transition: all 0.3s 0.2s;
    padding: 0 20px;
}
.desk, .desk h4, .team-hover .s-link a {
    text-align: center;
    color: #222;
}
.team-member:hover .team-hover .s-link {
    bottom: 10%;
}
.team-member:hover .team-hover, .team-member:hover .team-hover .desk, .team-member:hover .team-hover .s-link {
    opacity: 1;
}
.team-hover .s-link {
    position: absolute;
    bottom: 0;
    width: 100%;
    opacity: 0;
    text-align: center;
    -webkit-transform: translateY(45%);
    -ms-transform: translateY(45%);
    transform: translateY(45%);
    -webkit-transition: all 0.3s 0.2s;
    transition: all 0.3s 0.2s;
    font-size: 35px;
}
.desk, .desk h4, .team-hover .s-link a {
    text-align: center;
    color: #222;
}
.team-member .s-link a {
    margin: 0 10px;
    color: #333;
    font-size: 16px;
}
.team-title {
    position: static;
    padding: 20px 0;
    display: inline-block;
    letter-spacing: 2px;
    width: 100%;
}
.team-title h5 {
    margin-bottom: 0px;
    display: block;
    text-transform: uppercase;
}
.team-title span {
    font-size: 12px;
    text-transform: uppercase;
    color: #a5a5a5;
    letter-spacing: 1px;
}

	</style>


</head>
<body>




<?php if((!empty(Auth::user())) &&  ( Auth::user()->type== 'admin' )): ?>
			<a style="margin-top: 100px; margin-bottom: 20px;" href="<?php echo e(route('personal.create')); ?>" class="form-control btn btn-info">Добавить сотрудника</a>
<?php endif; ?>
<div class="container">
                    <div class="row text-center">
                        <div class="heading-title " style="margin-top: 102px;">
                            <h3 class="text-uppercase text-center" style="color: white">Наши сотрудники </h3>
                            <p class="p-top-30 half-txt text-center">Сотрудники, которые ощущают, что руководство заботиться о них не только как о подчиненных, а и как о личности, более продуктивны, довольны и лучше реализуют себя. Довольный сотрудник — довольный клиент. </p>
                        </div>
                        <?php $__currentLoopData = $personals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $personal): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                        <div class="col-md-4 col-sm-4" >

                            <div class="team-member">

                                <div class="team-img">
                                    <img src="<?php echo e($personal->picture); ?>" alt="team member"  style="width: 516px; height: 326px;">
                                </div>
                                <div class="team-hover">
                                    <div class="desk">
                                        <h4>Рад, видеть тебя здесь!</h4>
                                        <p>Если тебе нужен качественный, а главное быстрый ремонт бутс, то ты обратися по адресу. Просто свяжись со мной.</p>
                                        <p><?php echo e($personal->phone); ?></p>
                                    </div>
                                </div>
                            </div>
                            <div class="team-title">
                                <h5 style="color: white"><?php echo e($personal->name); ?></h5>
                                <span><?php echo e($personal->work); ?></span>
                            </div>
                                                    <?php if((!empty(Auth::user())) &&  ( Auth::user()->type == 'admin' )): ?>
				 		<div>
						<a href="<?php echo e(route('personal.edit', $personal)); ?>" class="form-control">Редактировать</a>
						<form action="<?php echo e(route('personal.destroy', [$personal->id])); ?>" method="POST">
						<?php echo e(csrf_field()); ?>

						<?php echo e(method_field('DELETE')); ?>

						<div class="col-sm-4">
						  <button type="submit" class="btn btn-danger mt-2">
							<i class="fa fa-plus" style="margin-left: -5px;"></i> Удалить 
						  </button>
						</div>
						</form>
				</div>
				<?php endif; ?>
              </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                        </div>
                        

                    </div>
                    <div class = "col-md-6 col-12" style="margin-top: 10px;"> 
				<?php echo e($personals->links('layouts.paginate')); ?> 
		</div>

                </div>

</body>		
</html>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>