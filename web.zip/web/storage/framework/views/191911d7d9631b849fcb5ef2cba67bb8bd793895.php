
<?php $__env->startSection('content'); ?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<style>
	body{

	background:
		-webkit-linear-gradient(45deg, hsla(0, 0%, 2%, 1) 0%, hsla(0, 0%, 2%, 0) 70%),
		-webkit-linear-gradient(315deg, hsla(0, 0%, 12%, 1) 10%, hsla(0, 0%, 12%, 0) 80%),
		-webkit-linear-gradient(225deg, hsla(0, 0%, 24%, 1) 10%, hsla(0, 0%, 24%, 0) 80%),
		-webkit-linear-gradient(135deg, hsla(0, 0%, 35%, 1) 100%, hsla(0, 0%, 35%, 0) 70%);
	background:
		linear-gradient(45deg, hsla(0, 0%, 2%, 1) 0%, hsla(0, 0%, 2%, 0) 70%),
		linear-gradient(135deg, hsla(0, 0%, 12%, 1) 10%, hsla(0, 0%, 12%, 0) 80%),
		linear-gradient(225deg, hsla(0, 0%, 24%, 1) 10%, hsla(0, 0%, 24%, 0) 80%),
		linear-gradient(315deg, hsla(0, 0%, 35%, 1) 100%, hsla(0, 0%, 35%, 0) 70%);
	} 
</style>
</head>
<body >
<div class = "container main-container " style="margin-top: 100px; ">
     <div class="panel-body">
	 <?php if(!empty(Auth::user())): ?>
		<form action="<?php echo e(route('review.store')); ?>" method="POST" class="mb-2">
				<?php echo e(csrf_field()); ?>

				<input type="text" name="text" class="form-control">
				
				<input type="submit" class="form-control btn btn-primary" value="Создать отзыв" style="width:50%; margin-left:25%">
				<?php else: ?>
				<div class="alert alert-info text-center" role="alert">
				 Необходимо авторизироваться
				</div>
				
		</form>	
			<?php endif; ?>
		<div>
		
			
		
			<div class="row" style="margin-top: 50px;">
			 <?php if(count($reviews) > 0): ?>
				 <?php $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
			
				<div class="col-6 btn btn success border" style="background-color: white">
					<h6 style="color:red;  border-radius:3px"><?php echo e($review->User->name); ?></h6>
					<hr>
					<span><?php echo e($review->text); ?></span>
					<pre class="text-right text-primary"><?php echo e($review->created_at); ?></pre>
						<?php if((!empty(Auth::user())) &&  ((Auth::user()->id == $review->User->id) || ( Auth::user()->type == 'admin' ))): ?>
					<a href="<?php echo e(route('review.edit', $review)); ?>" class="form-control mt-2">Редактировать</a>
						<form action="<?php echo e(route('review.destroy', [$review->id])); ?>" method="POST">
						<?php echo e(csrf_field()); ?>

						<?php echo e(method_field('DELETE')); ?>

						<div class="col-sm-4">
						  <button type="submit" class="btn btn-danger mt-2 form-control">
							<i class="fa fa-plus"></i> Удалить 
						  </button>
						</div>
						</form>
					<?php endif; ?>
				</div>
			
				<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
			<?php endif; ?>
			</div>
			<div class = "col-md-6 col-12"> 
			<?php echo e($reviews->links('layouts.paginate')); ?> 
			</div>
		</div>
		</div>
	</div>

</body>
</html>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>