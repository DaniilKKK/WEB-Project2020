<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Support\Facades\Auth;
class AdminCheck
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        if (Auth::guest() or !Auth::user()->AdminCheck()){ 
		session()->flash('message', 'Вход невозможен'); 
		return redirect()->route('Welcome'); 
		} 

		return $next($request); 
	} 
}
