<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Review;
use App\User;
use Illuminate\Support\Facades\Auth;

class ReviewController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view('welcome');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
		$users = User::all();
         return view('createReview', ['users' => $users]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $review = new Review;
		$review->text = $request->text;
		$review->id_user = Auth::user()->id;
		$review->save();

		return redirect('/reviews');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(Review $review)
    {
        $users = User::all()->where('id','!=',$review->id_user);
		 if ((Auth::user()) && ((Auth::user()->type == 'admin') || (Auth::user()->id == $review->id_user)))
		 {
        return view('updateReview', ['review' => $review, 'users' => $users]); 
		 }
		else
		{
		return redirect('/');
		}
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Review $review)
    {
		$review->text = $request->text;
		$review->id_user = $request ->id_user;
		$review->save();

		return redirect('/reviews');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Review $review)
    {
		 if ((Auth::user()) && ((Auth::user()->type == 'admin') || (Auth::user()->id == $review->id_user)))
		 {
        $review->delete();
		return redirect('/reviews');
		 }
		else
		{
		return redirect('/reviews');
		}
    }
}
