<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Order;
use App\Boot;
use App\Personal;
use Illuminate\Support\Facades\Auth;

class OrderController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
          return view('welcome');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
		$boots = Boot::All();
		$personals = Personal::All();
		if ((Auth::user()) && ((Auth::user()->type == 'admin') || (Auth::user()->type == 'personal')))
		{
          return view('createOrder', ['boots' => $boots, 'personals' => $personals]);
		}
		else
		{
			return redirect('/');
		}
	}
    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $order = new Order;
		$order->id_personal = $request->id_personal;
		$order->id_boot = $request ->id_boot;
		$order->work = $request ->work;
		$order->cost = $request->cost;
		$order->dateR = $request->dateR;
		$order->save();

		return redirect('/orders');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(Order $order)
    {
		
		$boots = Boot::All();
		$personals = Personal::All();
		if ((Auth::user()) && ((Auth::user()->type == 'admin') || (Auth::user()->id_personal == $order->Personals->id)))
		{
          return view('updateOrder', ['order' => $order, 'boots' => $boots, 'personals' => $personals]); 
		}
		else
		{
			return redirect('/');
		}
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Order $order)
    {
        $order->id_personal = $request->id_personal;
		$order->id_boot = $request ->id_boot;
		$order->work = $request ->work;
		$order->cost = $request->cost;
		$order->dateR = $request->dateR;
		$order->save();

		return redirect('/orders');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Order $order)
    {
		if ((Auth::user()) && ((Auth::user()->type == 'admin') || (Auth::user()->id_personal == $order->Personals->id)))
		{
         $order->delete();
		return redirect('/orders');
		}
		else
		{
			return redirect('/');
		}
    }
}
