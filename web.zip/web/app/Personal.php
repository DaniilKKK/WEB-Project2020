<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Personal extends Model
{
     public function Order()
	{
		return $this->hasMany('App\Order', 'id_personal');
	}
	
	public function Personal()
	{
		return $this->hasMany('App\User', 'id_personal');
	}
}
