<?php

namespace App;

use Illuminate\Notifications\Notifiable;
use Illuminate\Foundation\Auth\User as Authenticatable;

class User extends Authenticatable
{
    use Notifiable;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'name', 'email', 'password',
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password', 'remember_token',
    ];
	
	public function Review()
	{
		return $this->hasMany('App\Review', 'id_user');
	}
	
	public function Boots()
	{
		return $this->hasMany('App\Boot', 'id_user');
	}
	
	public function Personal()
	{
		return $this->belongsTo('App\Personal', 'id_personal');
	}
	
	public function AdminCheck()
	{
		return $this->type == 'admin';
	}
}
