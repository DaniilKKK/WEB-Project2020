@extends('layouts.app')
@section('content')
<!DOCTYPE html>
<html>
<head>
<style>
	body

	{

		background:
		-webkit-linear-gradient(45deg, hsla(0, 0%, 2%, 1) 0%, hsla(0, 0%, 2%, 0) 70%),
		-webkit-linear-gradient(315deg, hsla(0, 0%, 12%, 1) 10%, hsla(0, 0%, 12%, 0) 80%),
		-webkit-linear-gradient(225deg, hsla(0, 0%, 24%, 1) 10%, hsla(0, 0%, 24%, 0) 80%),
		-webkit-linear-gradient(135deg, hsla(0, 0%, 35%, 1) 100%, hsla(0, 0%, 35%, 0) 70%);
	background:
		linear-gradient(45deg, hsla(0, 0%, 2%, 1) 0%, hsla(0, 0%, 2%, 0) 70%),
		linear-gradient(135deg, hsla(0, 0%, 12%, 1) 10%, hsla(0, 0%, 12%, 0) 80%),
		linear-gradient(225deg, hsla(0, 0%, 24%, 1) 10%, hsla(0, 0%, 24%, 0) 80%),
		linear-gradient(315deg, hsla(0, 0%, 35%, 1) 100%, hsla(0, 0%, 35%, 0) 70%);
	}
 </style>
</head>
<body >
<div class = "container main-container fon"  style="margin-top: 100px">

		<a href="{{ route('order.create') }}" class="form-control btn btn-info" style="margin-top: 70px;">Добавить заказ</a>
        <table class="table " style="color: white;">
          <thead>
			<th>ID </th>
			<th>Обувь</th>
            <th>Мастер</th>
			<th>Стоимость</th>
			<th>Список работ</th>
			<th>Дата исполнения</th>
			<th> Действие </th>
          </thead>

          <tbody>
            @foreach ($orders as $order)
              <tr>
				<td>
					<div>{{ $order->id }}</div>
				</td>
                <td class="table-text">
					<div>{{ $order->Boots->name }}</div>
                </td>
				<td> 
					<div>{{ $order->Personals->name }}</div>
				</td>
				<td> 
					<div>{{ $order->cost }}</div>
				</td>
				<td> 
					<div>{{ $order->work }}</div>
				</td>
				<td> 
					<div>{{ $order->dateR }}</div>
				</td>
				@if ((!empty(Auth::user())) &&  ( Auth::user()->type == 'admin' ))
				<td> 
						<a href="{{ route('order.edit', $order) }}" class="form-control mt-2">Редактировать</a>
						<form action="{{route('order.destroy', [$order->id]) }}" method="POST">
						{{ csrf_field() }}
						{{ method_field('DELETE') }}
						<div class="col-sm-4">
						  <button type="submit" class="btn btn-danger mt-2">
							<i class="fa fa-plus"></i> Удалить 
						  </button>
						</div>
						</form>
				</td>
				@endif
              </tr>
            @endforeach
          </tbody>
        </table>
		<div class = "col-md-6 col-12"> 
			{{ $orders->links('layouts.paginate') }} 
</div>
	</div>
 </div>	
</body>
</html>

@endsection