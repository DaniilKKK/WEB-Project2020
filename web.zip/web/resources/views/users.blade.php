@extends('layouts.app')
@section('content')
<!DOCTYPE html>
<html>
<head>
	<title></title>
<style >
body{
background:
        -webkit-linear-gradient(45deg, hsla(0, 0%, 2%, 1) 0%, hsla(0, 0%, 2%, 0) 70%),
        -webkit-linear-gradient(315deg, hsla(0, 0%, 12%, 1) 10%, hsla(0, 0%, 12%, 0) 80%),
        -webkit-linear-gradient(225deg, hsla(0, 0%, 24%, 1) 10%, hsla(0, 0%, 24%, 0) 80%),
        -webkit-linear-gradient(135deg, hsla(0, 0%, 35%, 1) 100%, hsla(0, 0%, 35%, 0) 70%);
    background:
        linear-gradient(45deg, hsla(0, 0%, 2%, 1) 0%, hsla(0, 0%, 2%, 0) 70%),
        linear-gradient(135deg, hsla(0, 0%, 12%, 1) 10%, hsla(0, 0%, 12%, 0) 80%),
        linear-gradient(225deg, hsla(0, 0%, 24%, 1) 10%, hsla(0, 0%, 24%, 0) 80%),
        linear-gradient(315deg, hsla(0, 0%, 35%, 1) 100%, hsla(0, 0%, 35%, 0) 70%);;
	
}
</style>
</head>


<body>
<div class = "container main-container fon"  style="margin-top: 100px">
     <div class="panel-body">
		<a href="{{ route('user.create') }}" class="form-control btn btn-info">Добавить пользователя</a>
        <table class="table  task-table " style="color: white">
          <thead>
			<th>Имя </th>
			<th>email</th>
            <th>Уровень привилегий</th>
			<th> Действие </th>
          </thead>

          <tbody>
            @foreach ($users as $user)
              <tr>
				<td>
					<div>{{ $user->name }}</div>
				</td>
                <td class="table-text">
					<div>{{ $user->email }}</div>
                </td>
				<td> 
					<div>{{ $user->type }}</div>
				</td>
			
				<td> 
						<a href="{{ route('user.edit', $user) }}" class="form-control mt-2">Редактировать</a>
						<form action="{{route('user.destroy', [$user->id])}}" method="POST">
						{{ csrf_field() }}
						{{ method_field('DELETE') }}
						<div class="col-sm-4">
						  <button type="submit" class="btn btn-danger mt-2">
							<i class="fa fa-plus"></i> Удалить 
						  </button>
						</div>
						</form>
				</td>
              </tr>
            @endforeach
          </tbody>
        </table>
		<div class = "col-md-6 col-12"> 
			{{ $users->links('layouts.paginate') }} 
		</div>
	</div>
 </div>	
</body>
</html>
@endsection