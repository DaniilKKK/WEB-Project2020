 <!-- resources/views/tasks.blade.php -->

@extends('layouts.app')

@section('content')

 <!DOCTYPE html>
 <html>
 <head>
 	<title></title>
 </head>
<body style="background-image: url(https://images.wallpaperscraft.ru/image/zdanie_arhitektura_fasad_178061_2560x1440.jpg); ">
	<div class = "container main-container fon" style="margin-top: 180px">
	<div class="panel panel-default" style="color: white">
	  
		<div class="panel-body">
		<!-- Отображение ошибок проверки ввода -->
		@include('common.errors')


		<!-- Форма новой задачи -->
			<form action="{{ route('user.store') }}" method="POST" class="form-horizontal mt-3">
			  {{ csrf_field() }}
			  <!-- Имя задачи -->
			  <div class="form-group">
				<label for="user" class="col-sm-3 control-label">Имя</label>
				<div class="row">
					<div class="col-sm-5">
					  <input  type="text" name="name" id="user-name" class="form-control">
					</div>
				</div>
				<label for="user" class="col-sm-3 control-label">email</label>
				<div class="row">
					<div class="col-sm-5">
					  <input  type="text" name="email" id="user-email" class="form-control">
					</div>
				</div>
				<label for="user" class="col-sm-3 control-label">Пароль</label>
				<div class="row">
					<div class="col-sm-5">
					  <input  type="password" name="password" id="user-password" class="form-control">
					</div>
				</div>
				<label for="user" class="col-sm-3 control-label">Уровень привилегий</label>
				<div class="row">
					<div class="col-sm-7">
					 <select name="type" class="form-control">
					 <option value="user"> Пользователь </option>
					 <option value="admin"> Админ </option>
					 </select>
					</div>
				</div>
				<label for="order" class="col-sm-3 control-label">Сотрудник </label>
				<div class="row">
					<div class="col-sm-7">
					 <select name="id_personal" class="form-control">
					 <option>Не является аккаунтом сотрудника</option>
					 @foreach ($personals as $personal)
					 <option value="{{ $personal->id }}"> {{ $personal->name }} </option>
					 @endforeach
					 </select>
					</div>
				</div>
				
				<div class="col-sm-4">
				  <button type="submit" class="btn btn-primary mt-2 mb-2">
					<i class="fa fa-plus"></i> Создать 
				  </button>
				</div>
			  </div>
			 
			</form>
		</div>
	</div>	
</div>
</body>
 </html>
 
   
@endsection