@extends('layouts.app')
@section('content')



<!DOCTYPE html>
<html>
<head>

<style >
body{

	
	background:
		-webkit-linear-gradient(45deg, hsla(0, 0%, 2%, 1) 0%, hsla(0, 0%, 2%, 0) 70%),
		-webkit-linear-gradient(315deg, hsla(0, 0%, 12%, 1) 10%, hsla(0, 0%, 12%, 0) 80%),
		-webkit-linear-gradient(225deg, hsla(0, 0%, 24%, 1) 10%, hsla(0, 0%, 24%, 0) 80%),
		-webkit-linear-gradient(135deg, hsla(0, 0%, 35%, 1) 100%, hsla(0, 0%, 35%, 0) 70%);
	background:
		linear-gradient(45deg, hsla(0, 0%, 2%, 1) 0%, hsla(0, 0%, 2%, 0) 70%),
		linear-gradient(135deg, hsla(0, 0%, 12%, 1) 10%, hsla(0, 0%, 12%, 0) 80%),
		linear-gradient(225deg, hsla(0, 0%, 24%, 1) 10%, hsla(0, 0%, 24%, 0) 80%),
		linear-gradient(315deg, hsla(0, 0%, 35%, 1) 100%, hsla(0, 0%, 35%, 0) 70%);
	
}
</style>
	


</head>
<body >



                <div class = "container main-container fon" style="margin-top: 100px">
     <div class="panel-body">
		<div class="row">
			
		</div>
		<hr>
		@if ((!empty(Auth::user())) &&  ( Auth::user()->type == 'admin' ))
		<a href="{{ route('boot.create') }}" class="form-control btn btn-info">Добавить обувь</a>
		@endif
        <table class="table " style="color: white">
          <thead>
		  
			<th></th>
            <th>Название модели</th>
			<th>Описание</th>
			@if ((!empty(Auth::user())) &&  ( Auth::user()->type == 'admin' ))
			<th>Действия</th>
			@endif
          </thead>

          <tbody>
		  				
            @foreach ($boots as $boot)
              <tr>
				<td> 
					<div><img src="{{ $boot->picture }}" alt="pict" width="50%"></div>
				</td>
                <td class="table-text">
					<div>{{ $boot->name }}</div>
                </td>
				<td> 
					<div>{{ $boot->description}}</div>
				</td>
				@if ((!empty(Auth::user())) &&  ( Auth::user()->type == 'admin' ))
				 <td>
						<a href="{{ route('boot.edit', $boot) }}" class="form-control">Редактировать</a>
						<form action="{{route('boot.destroy', [$boot->id])}}" method="POST">
						{{ csrf_field() }}
						{{ method_field('DELETE') }}
						<div class="col-sm-4">
						  <button type="submit" class="btn btn-danger mt-2">
							<i class="fa fa-plus"></i> Удалить 
						  </button>
						</div>
						</form>
				</td>
				@endif
              </tr>
            @endforeach
          </tbody>
        </table>
		<div class = "col-md-6 col-12"> 
				{{ $boots->links('layouts.paginate') }} 
		</div>

		</div>
		</div>


</body>		
</html>
@endsection