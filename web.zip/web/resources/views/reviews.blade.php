@extends('layouts.app')
@section('content')
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<style>
	body{

	background:
		-webkit-linear-gradient(45deg, hsla(0, 0%, 2%, 1) 0%, hsla(0, 0%, 2%, 0) 70%),
		-webkit-linear-gradient(315deg, hsla(0, 0%, 12%, 1) 10%, hsla(0, 0%, 12%, 0) 80%),
		-webkit-linear-gradient(225deg, hsla(0, 0%, 24%, 1) 10%, hsla(0, 0%, 24%, 0) 80%),
		-webkit-linear-gradient(135deg, hsla(0, 0%, 35%, 1) 100%, hsla(0, 0%, 35%, 0) 70%);
	background:
		linear-gradient(45deg, hsla(0, 0%, 2%, 1) 0%, hsla(0, 0%, 2%, 0) 70%),
		linear-gradient(135deg, hsla(0, 0%, 12%, 1) 10%, hsla(0, 0%, 12%, 0) 80%),
		linear-gradient(225deg, hsla(0, 0%, 24%, 1) 10%, hsla(0, 0%, 24%, 0) 80%),
		linear-gradient(315deg, hsla(0, 0%, 35%, 1) 100%, hsla(0, 0%, 35%, 0) 70%);
	} 
</style>
</head>
<body >
<div class = "container main-container " style="margin-top: 100px; ">
     <div class="panel-body">
	 @if (!empty(Auth::user()))
		<form action="{{ route('review.store') }}" method="POST" class="mb-2">
				{{ csrf_field() }}
				<input type="text" name="text" class="form-control">
				
				<input type="submit" class="form-control btn btn-primary" value="Создать отзыв" style="width:50%; margin-left:25%">
				@else
				<div class="alert alert-info text-center" role="alert">
				 Необходимо авторизироваться
				</div>
				
		</form>	
			@endif
		<div>
		
			
		
			<div class="row" style="margin-top: 50px;">
			 @if (count($reviews) > 0)
				 @foreach ($reviews as $review)
			
				<div class="col-6 btn btn success border" style="background-color: white">
					<h6 style="color:red;  border-radius:3px">{{ $review->User->name }}</h6>
					<hr>
					<span>{{ $review->text }}</span>
					<pre class="text-right text-primary">{{ $review->created_at }}</pre>
						@if ((!empty(Auth::user())) &&  ((Auth::user()->id == $review->User->id) || ( Auth::user()->type == 'admin' )))
					<a href="{{ route('review.edit', $review) }}" class="form-control mt-2">Редактировать</a>
						<form action="{{ route('review.destroy', [$review->id]) }}" method="POST">
						{{ csrf_field() }}
						{{ method_field('DELETE') }}
						<div class="col-sm-4">
						  <button type="submit" class="btn btn-danger mt-2 form-control">
							<i class="fa fa-plus"></i> Удалить 
						  </button>
						</div>
						</form>
					@endif
				</div>
			
				@endforeach
			@endif
			</div>
			<div class = "col-md-6 col-12"> 
			{{ $reviews->links('layouts.paginate') }} 
			</div>
		</div>
		</div>
	</div>

</body>
</html>
@endsection