@extends('layouts.app')
@section('content')
<!DOCTYPE html>
<html>
<head>
  <title></title>


<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
</head>

<style >
video { 
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    object-fit: cover;
    object-position: center;
}
div#fashion {
  min-height: 100vh;
  display: flex;
  align-items: center;
  justify-content: center;
}

.video-h2 { 
  font-family: Century Schoolbook, Century Schoolbook L, Georgia, serif;
  font-size: 8vmin;
  text-align: center;
  margin: 2rem 3rem 0;
  mix-blend-mode: overlay;
  color: #fff;
  font-weight: 100;
}

.section-150px {
	padding: 150px 0;
}

.intro
{

	font-size: 20px;
	line-height: 40px;
	font-style: italic;
	font-weight: 100;
	color: #959595;
	text-align: center;
	width: 100%;
	margin: 0 auto;
}

.intro-in {
	width: 55%;
	margin: 0 auto;
	text-align: center;
}


.no-padding {
   padding: 0 !important;
   margin: 0 !important;
}
.services 
{
	background-color: #202020;
}
.services .ser-in {
	text-align: left;
	position: relative;
	padding: 15%;
	padding-right: 10%;
	padding-left: 25%;
	padding-bottom: 0px;
}
.services .ser-in .border-left {
	border-left: 10px solid #292f33;
}
.services .ser-part-2 {
	padding: 10%;
	padding-bottom: 1%;
}
.services .ser-part-2 li h6 {
	text-transform: uppercase;
	font-weight: bold;
	margin-bottom: 20px;
}



.img-responsive{
	display: block;
    max-width: 100%;
    height: auto;
}

.margin-bottom-40 {
    margin-bottom: 40px !important;
}

.margin-bottom-50 {
    margin-bottom: 50px !important;
}
.margin-bottom-30 {
    margin-bottom: 30px !important;
}

.border-left {
    border-left-color: rgba(255,255,255,0.09);
    margin-left: -130px;
}
.padding-left-20 {
    padding-left: 20px !important;
}

.margin-top-10 {
    margin-top: 10px !important;
}

.tittle-block h2 {
	font-size: 60px;
	font-weight: bold;
	color:  #959595;
}
.tittle-block h3 {
	line-height: 46px;
	font-weight: bold;
	color:  #959595;
}
.tittle-block p {
	font-family: 'Merriweather', serif;
	font-size: 16px;
	font-style: italic;
	color:  #959595;
}

.title-h2 { 
  font-family: Century Schoolbook, Century Schoolbook L, Georgia, serif;
  font-size: 8vmin;
  text-align: center;
  margin: 2rem 3rem 0;
  mix-blend-mode: overlay;
  color: #fff;
  font-weight: 100;
}
	.btn {

	font-size: 16px;
    line-height: 30px;
    font-style: italic;
    color: #959595;
    margin-top: 20px;
    display: inline-block;
    padding: 0px;
    border-radius: 0px;
    border-bottom: 1px solid #959595;
    padding-bottom: 5px;
    font-weight: 100;

}

.btn:hover{
	color: white;
	border-bottom: 1px solid white;

}
div#fashion {
  min-height: 100vh;
  display: flex;
  align-items: center;
  justify-content: center;
}

.footer {
    padding: 50px 0 20px 0;
    background-color: #090c14;
    color: #878c94;
}
.footer .title{
  text-align: left;
  color:#fff;
  font-size:25px;
}
.footer .social-icon{
  padding:0px;
  margin:0px;
}
.footer .social-icon a{
  display:inline-block;
  color:#fff;
  font-size:25px;
  padding:5px;
}
.footer .acount-icon a{
  display:block;
  color:#fff;
  font-size:18px;
  padding:5px;
  text-decoration:none;
}
.footer .acount-icon .fa{
  margin-right:25px;
}
.footer .category a {
    text-decoration: none;
    color: #fff;
    display: inline-block;
    padding: 5px 20px;
    margin: 1px;
    border-radius:4px;
    margin-top: 6px;
    background-color: black;
    border: solid 1px #fff;
}
.footer .payment{
  margin:0px;
  padding:0px;
  list-style-type:none
}
.footer .payment li{
  list-style-type:none
}
.footer .payment li a {
    text-decoration: none;
    display: inline-block;
    color: #fff;
    float: left;
    font-size: 25px;
    padding: 10px 10px;
}
</style>
<body>


<video poster="https://s3-us-west-2.amazonaws.com/s.cdpn.io/4273/fashion.jpg" playsinline autoplay muted loop>
<source src="https://s3-us-west-2.amazonaws.com/s.cdpn.io/4273/fashion.webm" type="video/webm">
<source src="http://thenewcode.com/assets/videos/fashion.mp4" type="video/mp4">
</video>
<div id="fashion">
  <h2 class="video-h2">Здесь заново перрождается футбол...</h2>
</div>


<section style="background-color: #202020; margin-top: -18px;" class="intro section-150px">
        <div class="container">
          <div class="intro-in">
            <p>Если ты не знаешь, что делать с бутсами
            <br> 
              отдай их нам, <strong>а нюансы мы обсудим потом.</strong> </p>
            <a href="{{ route('Review') }}" class="btn">Узнать больше</a>
             </div>
        </div>
</section>


      <section class="services">
        <div class="container-fluid"> 

          <div class="row">
            <div class="col-md-6 "> 
              <div class="ser-in">
                <div class="tittle-block margin-bottom-40">
                  <h2 class="margin-bottom-30" style="margin-left: -180px; margin-top: -115px;">Мы изобретаем бутсы заново</h2>
                  <p style="margin-left: -180px;">И верим в то, что та работа, которую мы делаем является отражением нас самих.</p>
                </div>
                <p class="border-left padding-left-20 margin-top-10" style="margin-left: -180px; color: #CFD0CF" >
Нам потребовалось много усилий и времени, чтобы вернуться туда, откуда все начиналось, мы наблюдали за ногами футболистов, за тем, в чем они играют и поэтому многое переосмыслили,мы переосмыслили полностью футбольную обувь и создали ее заново с использованием новейшихматериалов и технологий.</p>
                <a href="{{ route('Boot') }}" class="btn"style="margin-left: -180px;" >Посмотреть наши работы</a> </div>
            </div>
            

            <div class="col-md-6 no-padding" > <img class="img-responsive" src="http://gigafootball.net/date/photos/1178/715c35df011b4eca1cded2a5cd07b306.jpg"  alt="" > </div>
          </div>
          

          <div class="row"> 
            

            <div class="col-md-6 no-padding"> <img class="img-responsive" src="http://files2020.std-1120.ist.mospolytech.ru/boots.jpg" alt="" > 
            </div>

            <div class="col-md-6">
              <div class="ser-part-2">
                <div class="tittle-block margin-bottom-40">
                  <h3 class="margin-bottom-30 margin-top-0">От простых бутс до профессиональных  <br>
                    Долгий путь успеха!</h3>
                  <p>Мы команда единомышленников, скрепленных одной лишь целью <br>
                    Целью - принести футбол в судьбы каждого из вас</p>
                </div>
                <ul class="row">

                  <li class="col-sm-6 margin-bottom-50 " >
                    <p style="color: #CFD0CF">Благодаря нам, каждый из вас познает футбол заново
                    познает его совсем по-другому</p>
                  </li>
              </ul>
                
      </section>

<footer class="footer">
    <div class="container">
        <div class="row">
        <div class="col-sm-3">
            <h4 class="title">О компании</h4>
            <p>Мы прогрессивная компания с прогрессивными мыслями и прекрасным персаналом</p>
            <ul class="social-icon">
                <a href="#" class="social"><i class="fa fa-facebook" aria-hidden="true"></i></a>
                <a href="#" class="social"><i class="fa fa-twitter" aria-hidden="true"></i></a>
                <a href="#" class="social"><i class="fa fa-instagram" aria-hidden="true"></i></a>
                <a href="#" class="social"><i class="fa fa-youtube-play" aria-hidden="true"></i></a>
                <a href="#" class="social"><i class="fa fa-google" aria-hidden="true"></i></a>
                <a href="#" class="social"><i class="fa fa-dribbble" aria-hidden="true"></i></a>
            </ul>
        </div>
        <div class="col-sm-3">
            <h4 class="title">Навигация</h4>
            <span class="acount-icon">          
            <a href="{{ route('Welcome') }}"><i class="fa fa-heart" aria-hidden="true"></i> Главная</a>
            <a href="{{ route('Personal') }}"><i class="fa fa-users" aria-hidden="true"></i>Персонал</a>
            <a href="{{ route('Boot') }}"><i class="fa fa-user" aria-hidden="true"></i> Обувная лента</a>
            <a href="{{ route('Review') }}"><i class="fa fa-globe" aria-hidden="true"></i> Форум</a>           
            </span>
        </div>
        <div class="col-sm-3">
            <h4 class="title">Категории</h4>
            <div class="category">
                <a href="#">Мужской ремонт</a>
                <a href="#">Женский ремонт</a>
                <a href="#">Детский ремонт</a>        
            </div>
        </div>
        <div class="col-sm-3">
            <h4 class="title">Платежные системы</h4>
            <p>На нашем сайте принимают следующие виды банковских карт</p>
            <ul class="payment">
                <li><a href="#"><i class="fa fa-cc-amex" aria-hidden="true"></i></a></li>
                <li><a href="#"><i class="fa fa-credit-card" aria-hidden="true"></i></a></li>            
                <li><a href="#"><i class="fa fa-paypal" aria-hidden="true"></i></a></li>
                <li><a href="#"><i class="fa fa-cc-visa" aria-hidden="true"></i></a></li>
            </ul>
            </div>
        </div>
        <hr>
        <div class="row text-center"><a href="http://lacodeid.com/" style="color: #fff;">Copyright © Московский Политех 2021</a></div>
    </div>  
</footer>



<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
<link href="//netdna.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//netdna.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
<!------ Include the above in your HEAD tag ---------->

<link href="//maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Rubik" rel="stylesheet">

</body>
</html>



@endsection