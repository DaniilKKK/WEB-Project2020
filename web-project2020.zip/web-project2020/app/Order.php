<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Order extends Model
{
      public function Personals()
	{
		return $this->belongsTo('App\Personal', 'id_personal');
	}
	
	 public function Boots()
	{
		return $this->belongsTo('App\Boot', 'id_boot');
	}
	
}
