<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Personal;
use App\Boot;
use App\Order;
use App\Review;
use App\User;
use Illuminate\Support\Facades\Auth;

class MainController extends Controller
{
    public function index(){
		 return view('welcome');	
	}
	
	public function indexPersonal(){
		$personals=Personal::paginate(3);
		 return view('personals', ['personals'=>$personals]);	
	}
	
	public function indexBoot(){
		$boots=Boot::paginate(3);
		 return view('boots', ['boots'=>$boots]);	
	}
	
	public function indexOrder(){
		$orders=Order::paginate(5);
		if ((Auth::user()) && ((Auth::user()->type == 'admin') || (Auth::user()->type == 'personal')))
			return view('orders', ['orders'=>$orders]);
		else
		{
		  return redirect('/');
		}	 
	}
	
	public function indexReview(){
		$reviews=Review::paginate(8);
		 return view('reviews', ['reviews'=>$reviews]);	
	}
	
	public function indexUser(){
		$users=User::paginate(5);
		 return view('users', ['users'=>$users]);	
	}
	
}