@extends('layouts.app')

@section('content')

 <div class = "container main-container fon" style="margin-top: 100px">
	<div class="panel panel-default">
		<div class="panel-heading">
			Добавление
		</div>
	  
		<div class="panel-body">
		<!-- Отображение ошибок проверки ввода -->
		@include('common.errors')


		<!-- Форма новой задачи -->
			<form action="{{ route('boot.store') }}" method="POST" class="form-horizontal mt-3">
			  {{ csrf_field() }}
			  <!-- Имя задачи -->
			  <div class="form-group">
				<label for="boot" class="col-sm-3 control-label">Название</label>
				<div class="row">
					<div class="col-sm-5">
					  <input  type="text" name="name" id="boot-name" class="form-control">
					</div>
				</div>
				<label for="boot" class="col-sm-3 control-label">Описание</label>
				<div class="row">
					<div class="col-sm-5">
					  <input  type="text" name="description" id="boot-description" class="form-control">
					</div>
				</div>
				<label for="boot" class="col-sm-3 control-label">Изображение</label>
				<div class="row">
					<div class="col-sm-5">
					  <input  type="text" name="picture" id="personal-picture" class="form-control">
					</div>
				</div>
				<label for="boot" class="col-sm-3 control-label">Владелец</label>
				<div class="row">
					<div class="col-sm-7">
					 <select name="id_user" class="form-control">
					 <option>Не выбрано</option>
					 @foreach ($users as $user)
					 <option value="{{ $user->id }}"> {{ $user->name }} </option>
					 @endforeach
					 </select>
					</div>
				</div>
				<div class="col-sm-4">
				  <button type="submit" class="btn btn-primary mt-2 mb-2">
					<i class="fa fa-plus"></i> Добавить 
				  </button>
				</div>
			  </div>
			</form>
		</div>
	</div>	
</div>
   
@endsection