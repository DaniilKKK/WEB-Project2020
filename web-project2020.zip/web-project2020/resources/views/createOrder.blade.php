 <!-- resources/views/tasks.blade.php -->

@extends('layouts.app')

@section('content')

  
 <div class = "container main-container fon" style="margin-top: 100px">
	<div class="panel panel-default">
		<div class="panel-heading">
			Создание
		</div>
	  
		<div class="panel-body">
		<!-- Отображение ошибок проверки ввода -->
		@include('common.errors')


		<!-- Форма новой задачи -->
			<form action="{{ route('order.store') }}" method="POST" class="form-horizontal mt-3">
			  {{ csrf_field() }}
			  <!-- Имя задачи -->
			  <div class="form-group">
				<label for="order" class="col-sm-3 control-label">Мастер</label>
				<div class="row">
					<div class="col-sm-7">
					 <select name="id_personal" class="form-control">
					 <option>Не выбрано</option>
					 @foreach ($personals as $personal)
					 <option value="{{ $personal->id }}"> {{ $personal->name }} </option>
					 @endforeach
					 </select>
					</div>
				</div>
				<label for="order" class="col-sm-3 control-label">Обувь</label>
				<div class="row">
					<div class="col-sm-7">
					 <select name="id_boot" class="form-control">
					 <option>Не выбрано</option>
					 @foreach ($boots as $boot)
					 <option value="{{ $boot->id }}"> {{ $boot->name }} </option>
					 @endforeach
					 </select>
					</div>
				</div>
				<label for="order" class="col-sm-3 control-label">Произведённые работы</label>
				<div class="row">
					<div class="col-sm-5">
					  <input  type="text" name="work" id="order-work" class="form-control">
					</div>
				</div>
				<label for="order" class="col-sm-3 control-label">Стоимость</label>
				<div class="row">
					<div class="col-sm-5">
					  <input  type="text" name="cost" id="order-cost" class="form-control">
					</div>
				</div>
				<label for="order" class="col-sm-3 control-label">Дата выполнения</label>
				<div class="row">
					<div class="col-sm-5">
					  <input  type="date" name="dateR" id="order-dateR" class="form-control">
					</div>
				</div>
				<div class="col-sm-4">
				  <button type="submit" class="btn btn-primary mt-2 mb-2">
					<i class="fa fa-plus"></i> Добавить 
				  </button>
				</div>
			  </div>
			 
			</form>
		</div>
	</div>	
</div>
   
@endsection