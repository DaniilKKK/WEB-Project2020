<!DOCTYPE html>
<html lang="en">
  <head>
	<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>ZIGGY</title>
	<link rel="shortcut icon" href="" type="image/png"> 
   	<link rel="stylesheet" href="//netdna.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">        
	<style>
		body{
			background-image: url();
		}
		.fon{
			background-color: DarkGrey;
		}
		.hover-zoom {
		-webkit-transition: all 0.5s ease;
		-moz-transition: all 0.5s ease;
		transition: all 0.5s ease;
		}
		.hover-zoom:hover {
		-webkit-transform: scale(1.1);
		-moz-transform: scale(1.1);
		-o-transform: scale(1.1);
		transform: scale(1.1);
		-webkit-transition: all 0.5s ease;
		-moz-transition: all 0.5s ease;
		transition: all 0.5s ease;
		}

		#ChooseButton:hover, #add:hover{
			background-color: green;
			color: white;
		}
      </style>
	      <script>
        window.Laravel = <?php echo json_encode([
            'csrfToken' => csrf_token(),
        ]); ?>
    </script>
  </head>

  <body>
    <div class="container">
		<div class="fixed-top">
      <nav class="navbar navbar-expand-lg navbar-light bg-light">
	   <img src="" alt="logo" border="0" width="5%">
		  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
			<span class="navbar-toggler-icon"></span>
		  </button>
		  <div class="collapse navbar-collapse" id="navbarNav">
			<ul class="navbar-nav mr-auto">
			  <li class="nav-item active">
				<a class="nav-link" href="{{ route('Welcome') }}">Главная <span class="sr-only">(current)</span></a>
			  </li>
			  <li class="nav-item">
				<a class="nav-link" href="{{ route('Personal') }}">Персонал</a>
			  </li>
			  <li class="nav-item">
				<a class="nav-link" href="{{ route('Boot') }}">Обувная лента</a>
			  </li>
			  <li class="nav-item">
				<a class="nav-link" href="{{ route('Review') }}">Форум</a>
			  </li>
			  @if ((!empty(Auth::user())) &&  (( Auth::user()->type == 'admin' ) || ( Auth::user()->type == 'personal' )))
			  <li class="nav-item">
				<a class="nav-link" href="{{ route('Order') }}">Заказы</a>
			  </li>
			  @endif
			  @if ((!empty(Auth::user())) &&  ( Auth::user()->type == 'admin' ))
			  <li class="nav-item">
				<a class="nav-link" href="{{ route('User') }}">Пользователи</a>
			  </li>
			  @endif
			</ul>
			 <ul class="nav navbar-nav navbar-right">
                        <!-- Authentication Links -->
                        @if (Auth::guest())
                            <li><a href="{{ url('/login') }}" class="">Login</a></li>
                            <li><a href="{{ url('/register') }}" class="ml-2">Register</a></li>
                        @else
                            <li class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">
                                    {{ Auth::user()->name }} <span class="caret"></span>
                                </a>

                                <ul class="dropdown-menu" role="menu">
                                    <li>
                                        <a href="{{ url('/logout') }}"
                                            onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();" class="">
                                            Выйти
                                        </a>

                                        <form id="logout-form" action="{{ url('/logout') }}" method="POST" style="display: none;">
                                            {{ csrf_field() }}
                                        </form>
                                    </li>
                                </ul>
                            </li>
                        @endif
                    </ul>
		  </div>
		</nav>
		</div>

    @yield('content')
	</div>
	<script src="/js/app.js"></script>
	<script src="https://code.jquery.com/jquery.js"></script>
	<script src="http://netdna.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
  </body>
</html>