 <!-- resources/views/tasks.blade.php -->

@extends('layouts.app')

@section('content')

  
 <div class = "container main-container fon" style="margin-top: 100px">
	<div class="panel panel-default">
		<div class="panel-heading">
			Редактирование
		</div>
	  
		<div class="panel-body">
		<!-- Отображение ошибок проверки ввода -->
		@include('common.errors')


		<!-- Форма новой задачи -->
			<form action="{{ route('user.update', $user) }}" method="POST" class="form-horizontal mt-3">
			  {{ csrf_field() }}
				{{ method_field('PUT') }}
			  <!-- Имя задачи -->
			  <div class="form-group">
				<label for="user" class="col-sm-3 control-label">Имя</label>
				<div class="row">
					<div class="col-sm-5">
					  <input value="{{ $user->name }}" type="text" name="name" id="user-name" class="form-control">
					</div>
				</div>
				<label for="user" class="col-sm-3 control-label">email</label>
				<div class="row">
					<div class="col-sm-5">
					  <input value="{{ $user->email }}" type="text" name="email" id="user-email" class="form-control">
					</div>
				</div>
				<label for="user" class="col-sm-3 control-label">Пароль</label>
				<div class="row">
					<div class="col-sm-5">
					  <input placeholder="Введите текущий или новый пароль" type="password" name="password" id="user-password" class="form-control">
					</div>
				</div>
				<label for="user" class="col-sm-3 control-label">Уровень привилегий</label>
				<div class="row">
					<div class="col-sm-7">
					 <select name="type" class="form-control">
					 <option value="{{ $user->type }}">Текущая привилегия</option>
					 <option value="admin"> Админ </option>
					 <option value="user"> Пользователь </option>
					 </select>
					</div>
				</div>
				<label for="order" class="col-sm-3 control-label">Сотрудник </label>
				<div class="row">
					<div class="col-sm-7">
					 <select name="id_personal" class="form-control">
					 @if (!empty($user->Personal))
					 <option value="{{ $user->Personal->id }}">{{ $user->Personal->name}}</option>
					@else
						 <option>Не персонал</option>
					 @endif
					 @foreach ($personals as $personal)
					 <option value="{{ $personal->id }}"> {{ $personal->name }} </option>
					 @endforeach
					 </select>
					</div>
				</div>
				
				<div class="col-sm-4">
				  <button type="submit" class="btn btn-primary mt-2 mb-2">
					<i class="fa fa-plus"></i> Редактировать 
				  </button>
				</div>
			  </div>
			 
			</form>
		</div>
	</div>	
</div>
   
@endsection