 @extends('layouts.app')

@section('content')

 <div class = "container main-container fon" style="margin-top: 100px">
	<div class="panel panel-default">
		<div class="panel-heading">
			Редактирование
		</div>
	  
		<div class="panel-body">
		<!-- Отображение ошибок проверки ввода -->
		@include('common.errors')


		<!-- Форма новой задачи -->
			<form action="{{ route('personal.update', $personal) }}" method="POST" class="form-horizontal mt-3">
			  {{ csrf_field() }}
				{{ method_field('PUT') }}
			  <!-- Имя задачи -->
			  <div class="form-group">
				<label for="personal" class="col-sm-3 control-label">ФИО</label>
				<div class="row">
					<div class="col-sm-5">
					  <input value="{{ $personal->name }}" type="text" name="name" id="personal-name" class="form-control">
					</div>
				</div>
				<label for="personal" class="col-sm-3 control-label">Должность</label>
				<div class="row">
					<div class="col-sm-5">
					  <input value="{{ $personal->work }}" type="text" name="work" id="personal-work" class="form-control">
					</div>
				</div>
				<label for="personal" class="col-sm-3 control-label">Изображение</label>
				<div class="row">
					<div class="col-sm-5">
					  <input value="{{ $personal->picture }}" type="text" name="picture" id="personal-picture" class="form-control">
					</div>
				</div>
				<label for="personal" class="col-sm-3 control-label">Телефон</label>
				<div class="row">
					<div class="col-sm-5">
					  <input value="{{ $personal->phone }}" type="text" name="phone" id="personal-phone" class="form-control">
					</div>
				</div>
				<div class="col-sm-4">
				  <button type="submit" class="btn btn-primary mt-2 mb-2">
					<i class="fa fa-plus"></i> Редактировать 
				  </button>
				</div>
			  </div>
			 
			</form>
		</div>
	</div>	
</div>
   
@endsection