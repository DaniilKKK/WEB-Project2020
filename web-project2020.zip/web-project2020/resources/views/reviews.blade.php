@extends('layouts.app')
@section('content')
<div class = "container main-container fon" style="margin-top: 100px">
     <div class="panel-body">
	 @if (!empty(Auth::user()))
		<form action="{{ route('review.store') }}" method="POST" class="mb-2">
				{{ csrf_field() }}
				<input type="text" name="text" class="form-control">
				
				<input type="submit" class="form-control btn btn-primary" value="Создать отзыв" style="width:50%; margin-left:25%">
				@else
				<div class="alert alert-info text-center" role="alert">
				 Необходимо авторизироваться
				</div>
				
		</form>	
			@endif
		<div>
		
			<h2 style="background-color:dodgerblue;  border-radius:3px"><pre style="color:white;">  Отзывы</pre></h2>
		
			<div class="row">
			 @if (count($reviews) > 0)
				 @foreach ($reviews as $review)
			
				<div class="col-6 btn btn success border border-warning">
					<h6 style="color:red;  border-radius:3px">{{ $review->User->name }}</h6>
					<hr>
					<span>{{ $review->text }}</span>
					<pre class="text-right text-primary">{{ $review->created_at }}</pre>
						@if ((!empty(Auth::user())) &&  ((Auth::user()->id == $review->User->id) || ( Auth::user()->type == 'admin' )))
					<a href="{{ route('review.edit', $review) }}" class="form-control mt-2">Редактировать</a>
						<form action="{{ route('review.destroy', [$review->id]) }}" method="POST">
						{{ csrf_field() }}
						{{ method_field('DELETE') }}
						<div class="col-sm-4">
						  <button type="submit" class="btn btn-danger mt-2 form-control">
							<i class="fa fa-plus"></i> Удалить 
						  </button>
						</div>
						</form>
					@endif
				</div>
			
				@endforeach
			@endif
			</div>
			<div class = "col-md-6 col-12"> 
			{{ $reviews->links('layouts.paginate') }} 
			</div>
		</div>
		</div>
	</div>

@endsection