<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateOrdersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('orders', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('id_personal')->unsigned();
			$table->integer('id_boot')->unsigned();
			$table->string('cost');
			$table->date('dateR');
			$table->foreign('id_personal')->references('id')->on('personals');
			$table->foreign('id_boot')->references('id')->on('boots');
			
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('orders');
    }
}
