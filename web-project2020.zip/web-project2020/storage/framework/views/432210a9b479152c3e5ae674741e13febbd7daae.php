<?php $__env->startSection('content'); ?>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Laravel</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Raleway:100,600" rel="stylesheet" type="text/css">

        <!-- Styles -->
    </head>
    <body>
		<div class="container main-container fon">
			<div class="row">
				<div class ="col">
				</div>
			</div>
		<div id="alert"></div>
		<hr>
		<h1 style="margin-top:100px;">ГЛАВНАЯ СТРАНИЦА </h1>
		<div class="row">
		</div>
        <div class="flex-center position-ref full-height">
		</div>
		
	</body>
</html>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>