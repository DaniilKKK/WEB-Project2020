
<?php $__env->startSection('content'); ?>
<div class = "container main-container fon" style="margin-top: 100px">
     <div class="panel-body">
		<div class="row">
			<h1> Какой-то текст </h1>
		</div>
		<hr>
		<h2 style="background-color:Black;  border-radius:3px"><pre style="color:white;"> Обувь</pre></h2>
		<?php if((!empty(Auth::user())) &&  ( Auth::user()->type == 'admin' )): ?>
		<a href="<?php echo e(route('boot.create')); ?>" class="form-control btn btn-info">Добавить обувь</a>
		<?php endif; ?>
        <table class="table table-hover table-dark">
          <thead>
		  
			<th></th>
            <th>Название модели</th>
			<th>Описание</th>
			<?php if((!empty(Auth::user())) &&  ( Auth::user()->type == 'admin' )): ?>
			<th>Действия</th>
			<?php endif; ?>
          </thead>

          <tbody>
		  				
            <?php $__currentLoopData = $boots; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $boot): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
              <tr>
				<td> 
					<div><img src="<?php echo e($boot->picture); ?>" alt="pict" width="50%"></div>
				</td>
                <td class="table-text">
					<div><?php echo e($boot->name); ?></div>
                </td>
				<td> 
					<div><?php echo e($boot->description); ?></div>
				</td>
				<?php if((!empty(Auth::user())) &&  ( Auth::user()->type == 'admin' )): ?>
				 <td>
						<a href="<?php echo e(route('boot.edit', $boot)); ?>" class="form-control">Редактировать</a>
						<form action="<?php echo e(route('boot.destroy', [$boot->id])); ?>" method="POST">
						<?php echo e(csrf_field()); ?>

						<?php echo e(method_field('DELETE')); ?>

						<div class="col-sm-4">
						  <button type="submit" class="btn btn-danger mt-2">
							<i class="fa fa-plus"></i> Удалить 
						  </button>
						</div>
						</form>
				</td>
				<?php endif; ?>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
          </tbody>
        </table>
		<div class = "col-md-6 col-12"> 
				<?php echo e($boots->links('layouts.paginate')); ?> 
		</div>

		</div>
		</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>