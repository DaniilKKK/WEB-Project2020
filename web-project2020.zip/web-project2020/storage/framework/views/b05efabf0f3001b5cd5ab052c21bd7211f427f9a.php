 <!-- resources/views/tasks.blade.php -->



<?php $__env->startSection('content'); ?>

  
 <div class = "container main-container fon" style="margin-top: 100px">
	<div class="panel panel-default">
		<div class="panel-heading">
			Создание
		</div>
	  
		<div class="panel-body">
		<!-- Отображение ошибок проверки ввода -->
		<?php echo $__env->make('common.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


		<!-- Форма новой задачи -->
			<form action="<?php echo e(route('order.store')); ?>" method="POST" class="form-horizontal mt-3">
			  <?php echo e(csrf_field()); ?>

			  <!-- Имя задачи -->
			  <div class="form-group">
				<label for="order" class="col-sm-3 control-label">Мастер</label>
				<div class="row">
					<div class="col-sm-7">
					 <select name="id_personal" class="form-control">
					 <option>Не выбрано</option>
					 <?php $__currentLoopData = $personals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $personal): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
					 <option value="<?php echo e($personal->id); ?>"> <?php echo e($personal->name); ?> </option>
					 <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
					 </select>
					</div>
				</div>
				<label for="order" class="col-sm-3 control-label">Обувь</label>
				<div class="row">
					<div class="col-sm-7">
					 <select name="id_boot" class="form-control">
					 <option>Не выбрано</option>
					 <?php $__currentLoopData = $boots; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $boot): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
					 <option value="<?php echo e($boot->id); ?>"> <?php echo e($boot->name); ?> </option>
					 <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
					 </select>
					</div>
				</div>
				<label for="order" class="col-sm-3 control-label">Произведённые работы</label>
				<div class="row">
					<div class="col-sm-5">
					  <input  type="text" name="work" id="order-work" class="form-control">
					</div>
				</div>
				<label for="order" class="col-sm-3 control-label">Стоимость</label>
				<div class="row">
					<div class="col-sm-5">
					  <input  type="text" name="cost" id="order-cost" class="form-control">
					</div>
				</div>
				<label for="order" class="col-sm-3 control-label">Дата выполнения</label>
				<div class="row">
					<div class="col-sm-5">
					  <input  type="date" name="dateR" id="order-dateR" class="form-control">
					</div>
				</div>
				<div class="col-sm-4">
				  <button type="submit" class="btn btn-primary mt-2 mb-2">
					<i class="fa fa-plus"></i> Добавить 
				  </button>
				</div>
			  </div>
			 
			</form>
		</div>
	</div>	
</div>
   
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>