 

<?php $__env->startSection('content'); ?>

 <div class = "container main-container fon" style="margin-top: 100px">
	<div class="panel panel-default">
		<div class="panel-heading">
			Создание
		</div>
	  
		<div class="panel-body">
		<!-- Отображение ошибок проверки ввода -->
		<?php echo $__env->make('common.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


		<!-- Форма новой задачи -->
			<form action="<?php echo e(route('personal.store')); ?>" method="POST" class="form-horizontal mt-3">
			  <?php echo e(csrf_field()); ?>

			  <!-- Имя задачи -->
			  <div class="form-group">
				<label for="personal" class="col-sm-3 control-label">ФИО</label>
				<div class="row">
					<div class="col-sm-5">
					  <input  type="text" name="name" id="personal-name" class="form-control">
					</div>
				</div>
				<label for="personal" class="col-sm-3 control-label">Должность</label>
				<div class="row">
					<div class="col-sm-5">
					  <input  type="text" name="work" id="personal-work" class="form-control">
					</div>
				</div>
				<label for="personal" class="col-sm-3 control-label">Изображение</label>
				<div class="row">
					<div class="col-sm-5">
					  <input  type="text" name="picture" id="personal-picture" class="form-control">
					</div>
				</div>
				<label for="personal" class="col-sm-3 control-label">Телефон</label>
				<div class="row">
					<div class="col-sm-5">
					  <input  type="text" name="phone" id="personal-phone" class="form-control">
					</div>
				</div>
				<div class="col-sm-4">
				  <button type="submit" class="btn btn-primary mt-2 mb-2">
					<i class="fa fa-plus"></i> Добавить 
				  </button>
				</div>
			  </div>
			 
			</form>
		</div>
	</div>	
</div>
   
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>