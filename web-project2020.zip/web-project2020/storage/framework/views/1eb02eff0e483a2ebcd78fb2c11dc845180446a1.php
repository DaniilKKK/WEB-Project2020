
<?php $__env->startSection('content'); ?>
<div class = "container main-container fon" style="margin-top: 100px">
     <div class="panel-body">
		<div class="row">
			<h1> Какой-то текст </h1>
		</div>
		<hr>
		<h2 style="background-color:Black;  border-radius:3px"><pre style="color:white;">  Наши мастера</pre></h2>
		<?php if((!empty(Auth::user())) &&  ( Auth::user()->type== 'admin' )): ?>
			<a href="<?php echo e(route('personal.create')); ?>" class="form-control btn btn-info">Добавить сотрудника</a>
		<?php endif; ?>
        <table class="table table-hover table-dark">
          <thead>
		  
			<th></th>
            <th>ФИО</th>
			<th>Специализация</th>
			<th>Телефон</th>
			<?php if((!empty(Auth::user())) &&  ( Auth::user()->type == 'admin' )): ?>
			<th>Действия</th>
			<?php endif; ?>
          </thead>

          <tbody>
		  				
            <?php $__currentLoopData = $personals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $personal): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
              <tr>
				<td> 
					<div><img src="<?php echo e($personal->picture); ?>" alt="pict" width="50%"></div>
				</td>
                <td class="table-text">
					<div><?php echo e($personal->name); ?></div>
                </td>
				
				<td> 
					<div><?php echo e($personal->work); ?></div>
				</td>
				<td> 
					<div><?php echo e($personal->phone); ?></div>
				</td>
				<?php if((!empty(Auth::user())) &&  ( Auth::user()->type == 'admin' )): ?>
				 <td>
						<a href="<?php echo e(route('personal.edit', $personal)); ?>" class="form-control">Редактировать</a>
						<form action="<?php echo e(route('personal.destroy', [$personal->id])); ?>" method="POST">
						<?php echo e(csrf_field()); ?>

						<?php echo e(method_field('DELETE')); ?>

						<div class="col-sm-4">
						  <button type="submit" class="btn btn-danger mt-2">
							<i class="fa fa-plus"></i> Удалить 
						  </button>
						</div>
						</form>
				</td>
				<?php endif; ?>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
          </tbody>
        </table>
		<div class = "col-md-6 col-12"> 
				<?php echo e($personals->links('layouts.paginate')); ?> 
		</div>

		</div>
		</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>